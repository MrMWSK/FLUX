package com.example.ui.flux

import android.content.Context
import android.content.Intent
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoFixHigh
import androidx.compose.material.icons.filled.Code
import androidx.compose.material.icons.filled.ContentPaste
import androidx.compose.material.icons.filled.FactCheck
import androidx.compose.material.icons.filled.FileUpload
import androidx.compose.material.icons.filled.FormatAlignLeft
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Save
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.Undo
import androidx.compose.material.icons.filled.VerticalSplit
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.ScrollableTabRow
import androidx.compose.material3.Surface
import androidx.compose.material3.Tab
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.AuditCategory
import com.example.data.model.FindingSeverity
import com.example.domain.FluxEngine
import com.example.ui.EditorViewMode
import com.example.ui.MainViewModel
import com.example.ui.ViewerDevice
import com.example.ui.components.FindingCard
import com.example.ui.components.HtmlViewerPane
import com.example.ui.components.ResolveFindingModal
import com.example.ui.components.SaveAsDialog
import com.example.ui.components.SaveFormat
import com.example.ui.components.ScoreCard
import com.example.ui.theme.JetBrainsMono
import com.example.ui.theme.MintAccent

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun FluxScreen(
    viewModel: MainViewModel,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val clipboardManager = LocalClipboardManager.current

    val source by viewModel.fluxSource.collectAsState()
    val prevSource by viewModel.fluxPreviousSource.collectAsState()
    val docName by viewModel.fluxDocumentName.collectAsState()
    val report by viewModel.fluxReport.collectAsState()
    val severityFilter by viewModel.fluxSeverityFilter.collectAsState()
    val activeCategory by viewModel.fluxAuditCategory.collectAsState()
    val targetLang by viewModel.fluxTargetLanguage.collectAsState()
    val isAnalyzing by viewModel.isAnalyzingFlux.collectAsState()

    val editorViewMode by viewModel.editorViewMode.collectAsState()
    val viewerDevice by viewModel.viewerDevice.collectAsState()
    val viewerZoom by viewModel.viewerZoom.collectAsState()
    val activeFindingForResolution by viewModel.activeFindingForResolution.collectAsState()

    var showSaveAsDialog by remember { mutableStateOf(false) }
    var sampleMenuExpanded by remember { mutableStateOf(false) }
    var langMenuExpanded by remember { mutableStateOf(false) }

    // File Picker for Opening HTML
    val filePickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent()
    ) { uri: Uri? ->
        if (uri != null) {
            try {
                context.contentResolver.openInputStream(uri)?.use { stream ->
                    val text = stream.bufferedReader().use { it.readText() }
                    val name = uri.lastPathSegment?.substringAfterLast("/") ?: "imported.html"
                    viewModel.setFluxSource(text, name)
                    viewModel.showFeedback("Loaded file: $name")
                }
            } catch (e: Exception) {
                viewModel.showFeedback("Error opening file: ${e.message}", isError = true)
            }
        }
    }

    // Storage Access Framework launcher for Save As file creation
    var pendingExportContent by remember { mutableStateOf("") }
    val saveFileLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.CreateDocument("text/html")
    ) { uri: Uri? ->
        if (uri != null && pendingExportContent.isNotEmpty()) {
            try {
                context.contentResolver.openOutputStream(uri)?.use { out ->
                    out.write(pendingExportContent.toByteArray(Charsets.UTF_8))
                }
                viewModel.showFeedback("File successfully exported!")
            } catch (e: Exception) {
                viewModel.showFeedback("Export error: ${e.message}", isError = true)
            }
        }
    }

    fun shareContent(content: String, title: String, mimeType: String = "text/plain") {
        val sendIntent = Intent().apply {
            action = Intent.ACTION_SEND
            putExtra(Intent.EXTRA_TEXT, content)
            putExtra(Intent.EXTRA_TITLE, title)
            type = mimeType
        }
        context.startActivity(Intent.createChooser(sendIntent, title))
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(Color(0xFF141416))
            .testTag("flux_screen")
    ) {
        // Adobe Creative Suite Top Application Bar
        Surface(
            modifier = Modifier.fillMaxWidth(),
            color = Color(0xFF1E1E22),
            tonalElevation = 4.dp,
            border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF2C2C33))
        ) {
            Column(modifier = Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 10.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    // Studio Brand
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(30.dp)
                                .clip(RoundedCornerShape(7.dp))
                                .background(MintAccent),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = "Fx",
                                fontSize = 16.sp,
                                fontWeight = FontWeight.Black,
                                color = Color(0xFF10251D)
                            )
                        }
                        Column {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(
                                    text = "MrMWSK ",
                                    fontSize = 17.sp,
                                    fontWeight = FontWeight.Black,
                                    color = Color.White
                                )
                                Text(
                                    text = "FLUX",
                                    fontSize = 17.sp,
                                    fontWeight = FontWeight.Black,
                                    color = MintAccent
                                )
                            }
                            Text(
                                text = "HTML Studio · Audit, Live View & Guided Resolver",
                                fontSize = 11.sp,
                                color = Color(0xFF9E9EA8)
                            )
                        }
                    }

                    // View Mode Switcher: Code, HTML Viewer, Split View
                    Row(
                        modifier = Modifier
                            .clip(RoundedCornerShape(8.dp))
                            .background(Color(0xFF282830))
                            .border(1.dp, Color(0xFF383844), RoundedCornerShape(8.dp))
                            .padding(2.dp),
                        horizontalArrangement = Arrangement.spacedBy(2.dp)
                    ) {
                        ViewModeButton(
                            title = "Code",
                            icon = Icons.Default.Code,
                            isSelected = editorViewMode == EditorViewMode.CODE,
                            onClick = { viewModel.setEditorViewMode(EditorViewMode.CODE) }
                        )
                        ViewModeButton(
                            title = "HTML Viewer",
                            icon = Icons.Default.Visibility,
                            isSelected = editorViewMode == EditorViewMode.HTML_VIEWER,
                            onClick = { viewModel.setEditorViewMode(EditorViewMode.HTML_VIEWER) }
                        )
                        ViewModeButton(
                            title = "Split",
                            icon = Icons.Default.VerticalSplit,
                            isSelected = editorViewMode == EditorViewMode.SPLIT,
                            onClick = { viewModel.setEditorViewMode(EditorViewMode.SPLIT) }
                        )
                    }

                    // Quick Action Icons
                    Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                        if (prevSource != null) {
                            IconButton(onClick = { viewModel.undoFluxFixes() }, modifier = Modifier.size(32.dp)) {
                                Icon(Icons.Default.Undo, contentDescription = "Undo", tint = Color(0xFF9E9EA8))
                            }
                        }
                        IconButton(onClick = { viewModel.formatHtmlSource() }, modifier = Modifier.size(32.dp)) {
                            Icon(Icons.Default.FormatAlignLeft, contentDescription = "Format HTML", tint = Color(0xFF9E9EA8))
                        }
                        IconButton(onClick = { showSaveAsDialog = true }, modifier = Modifier.size(32.dp)) {
                            Icon(Icons.Default.Save, contentDescription = "Save As", tint = MintAccent)
                        }
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))

                // Docked Action Ribbon
                FlowRow(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Button(
                        onClick = { viewModel.runFluxCheck() },
                        enabled = source.isNotBlank() && !isAnalyzing,
                        colors = ButtonDefaults.buttonColors(containerColor = MintAccent),
                        contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 14.dp, vertical = 6.dp)
                    ) {
                        if (isAnalyzing) {
                            CircularProgressIndicator(modifier = Modifier.size(14.dp), color = Color(0xFF10251D), strokeWidth = 2.dp)
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Auditing…", color = Color(0xFF10251D), fontWeight = FontWeight.Bold, fontSize = 12.sp)
                        } else {
                            Icon(Icons.Default.PlayArrow, contentDescription = null, tint = Color(0xFF10251D), modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Run Audit", color = Color(0xFF10251D), fontWeight = FontWeight.Bold, fontSize = 12.sp)
                        }
                    }

                    Button(
                        onClick = { viewModel.applyFluxSafeFixes() },
                        enabled = source.isNotBlank(),
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF282830)),
                        contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 12.dp, vertical = 6.dp)
                    ) {
                        Icon(Icons.Default.AutoFixHigh, contentDescription = null, tint = MintAccent, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Apply Safe Fixes", color = Color.White, fontSize = 12.sp)
                    }

                    OutlinedButton(
                        onClick = { showSaveAsDialog = true },
                        contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 12.dp, vertical = 6.dp)
                    ) {
                        Icon(Icons.Default.Save, contentDescription = null, modifier = Modifier.size(14.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Save As…", fontSize = 12.sp)
                    }

                    Box {
                        OutlinedButton(
                            onClick = { sampleMenuExpanded = true },
                            contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 12.dp, vertical = 6.dp)
                        ) {
                            Text("Templates ▾", fontSize = 12.sp)
                        }
                        DropdownMenu(expanded = sampleMenuExpanded, onDismissRequest = { sampleMenuExpanded = false }) {
                            DropdownMenuItem(text = { Text("MrMWSK FLUX Test Suite (Issues)") }, onClick = { viewModel.loadFluxSample(0); sampleMenuExpanded = false })
                            DropdownMenuItem(text = { Text("Clean Offline Compliant Guide") }, onClick = { viewModel.loadFluxSample(1); sampleMenuExpanded = false })
                            DropdownMenuItem(text = { Text("Multilingual HTML Anthology") }, onClick = { viewModel.loadFluxSample(2); sampleMenuExpanded = false })
                        }
                    }

                    Box {
                        OutlinedButton(
                            onClick = { langMenuExpanded = true },
                            contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 10.dp, vertical = 6.dp)
                        ) {
                            Text("Lang: $targetLang ▾", fontSize = 12.sp)
                        }
                        DropdownMenu(expanded = langMenuExpanded, onDismissRequest = { langMenuExpanded = false }) {
                            listOf("en" to "English", "ur" to "Urdu", "ar" to "Arabic", "es" to "Spanish", "fr" to "French", "de" to "German").forEach { (code, name) ->
                                DropdownMenuItem(
                                    text = { Text("$name ($code)") },
                                    onClick = { viewModel.setTargetLanguage(code); langMenuExpanded = false }
                                )
                            }
                        }
                    }

                    IconButton(onClick = { filePickerLauncher.launch("text/html") }, modifier = Modifier.size(32.dp)) {
                        Icon(Icons.Default.FileUpload, contentDescription = "Open File", tint = Color.White, modifier = Modifier.size(18.dp))
                    }

                    IconButton(
                        onClick = {
                            val clip = clipboardManager.getText()?.text ?: ""
                            if (clip.isNotBlank()) viewModel.setFluxSource(clip, "pasted.html")
                        },
                        modifier = Modifier.size(32.dp)
                    ) {
                        Icon(Icons.Default.ContentPaste, contentDescription = "Paste", tint = Color.White, modifier = Modifier.size(18.dp))
                    }
                }
            }
        }

        // Central Studio Body (Editor / HTML Viewer / Split View / Inspector)
        BoxWithConstraints(modifier = Modifier.fillMaxSize()) {
            val isTabletOrDesktop = maxWidth >= 840.dp

            if (isTabletOrDesktop) {
                // Wide Screen Studio Layout: Main Canvas on Left + Docked Inspector on Right
                Row(
                    modifier = Modifier.fillMaxSize().padding(12.dp),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    // Left: Workspace View (Code / HTML Viewer / Split)
                    Surface(
                        modifier = Modifier.weight(1.15f).fillMaxHeight(),
                        shape = RoundedCornerShape(12.dp),
                        color = Color(0xFF1E1E22),
                        border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF2C2C33))
                    ) {
                        WorkspaceCanvas(
                            viewMode = editorViewMode,
                            source = source,
                            docName = docName,
                            viewerDevice = viewerDevice,
                            viewerZoom = viewerZoom,
                            onSourceChange = { viewModel.setFluxSource(it, docName) },
                            onDeviceChange = { viewModel.setViewerDevice(it) },
                            onZoomChange = { viewModel.setViewerZoom(it) }
                        )
                    }

                    // Right: Docked Audit & Diagnostics Panel
                    Surface(
                        modifier = Modifier.weight(0.85f).fillMaxHeight(),
                        shape = RoundedCornerShape(12.dp),
                        color = Color(0xFF1E1E22),
                        border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF2C2C33))
                    ) {
                        DockedInspectorPane(
                            report = report,
                            docName = docName,
                            severityFilter = severityFilter,
                            activeCategory = activeCategory,
                            onSeveritySelect = { viewModel.setFluxSeverityFilter(it) },
                            onCategorySelect = { viewModel.setFluxAuditCategory(it) },
                            onResolveFinding = { viewModel.openFindingResolution(it) },
                            onAutoFixFinding = { viewModel.resolveSpecificFinding(it) },
                            onExportJson = {
                                if (report != null) {
                                    val json = FluxEngine.exportReportAsJson(report!!, docName)
                                    shareContent(json, "report_$docName.json", "application/json")
                                }
                            },
                            onExportCsv = {
                                if (report != null) {
                                    val csv = FluxEngine.exportReportAsCsv(report!!, docName)
                                    shareContent(csv, "findings_$docName.csv", "text/csv")
                                }
                            }
                        )
                    }
                }
            } else {
                // Mobile View: Single Column with Bottom Docked Inspector
                Column(modifier = Modifier.fillMaxSize()) {
                    Box(modifier = Modifier.weight(1f).fillMaxWidth()) {
                        WorkspaceCanvas(
                            viewMode = editorViewMode,
                            source = source,
                            docName = docName,
                            viewerDevice = viewerDevice,
                            viewerZoom = viewerZoom,
                            onSourceChange = { viewModel.setFluxSource(it, docName) },
                            onDeviceChange = { viewModel.setViewerDevice(it) },
                            onZoomChange = { viewModel.setViewerZoom(it) }
                        )
                    }

                    // Bottom Docked Inspector in Mobile
                    Surface(
                        modifier = Modifier.fillMaxWidth().height(260.dp),
                        color = Color(0xFF1E1E22),
                        border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF2C2C33))
                    ) {
                        DockedInspectorPane(
                            report = report,
                            docName = docName,
                            severityFilter = severityFilter,
                            activeCategory = activeCategory,
                            onSeveritySelect = { viewModel.setFluxSeverityFilter(it) },
                            onCategorySelect = { viewModel.setFluxAuditCategory(it) },
                            onResolveFinding = { viewModel.openFindingResolution(it) },
                            onAutoFixFinding = { viewModel.resolveSpecificFinding(it) },
                            onExportJson = {
                                if (report != null) {
                                    val json = FluxEngine.exportReportAsJson(report!!, docName)
                                    shareContent(json, "report_$docName.json", "application/json")
                                }
                            },
                            onExportCsv = {
                                if (report != null) {
                                    val csv = FluxEngine.exportReportAsCsv(report!!, docName)
                                    shareContent(csv, "findings_$docName.csv", "text/csv")
                                }
                            }
                        )
                    }
                }
            }
        }

        // Save As Dialog
        if (showSaveAsDialog) {
            SaveAsDialog(
                initialFileName = docName,
                onSaveToLibrary = { title, name ->
                    viewModel.saveAsDocument(title, name)
                },
                onExportToStorage = { name, format ->
                    pendingExportContent = when (format) {
                        SaveFormat.HTML -> source
                        SaveFormat.JSON_REPORT -> if (report != null) FluxEngine.exportReportAsJson(report!!, name) else source
                        SaveFormat.CSV_REPORT -> if (report != null) FluxEngine.exportReportAsCsv(report!!, name) else source
                    }
                    saveFileLauncher.launch(name)
                },
                onDismiss = { showSaveAsDialog = false }
            )
        }

        // Guided Error Resolution Modal
        activeFindingForResolution?.let { finding ->
            ResolveFindingModal(
                finding = finding,
                onApplyFix = { viewModel.resolveSpecificFinding(it) },
                onDismiss = { viewModel.closeFindingResolution() },
                onCopyCode = { viewModel.showFeedback("Solution code copied to clipboard") }
            )
        }
    }
}

@Composable
private fun ViewModeButton(
    title: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    isSelected: Boolean,
    onClick: () -> Unit
) {
    Surface(
        shape = RoundedCornerShape(6.dp),
        color = if (isSelected) MintAccent else Color.Transparent,
        modifier = Modifier.clip(RoundedCornerShape(6.dp))
    ) {
        Row(
            modifier = Modifier
                .clickable { onClick() }
                .padding(horizontal = 8.dp, vertical = 4.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                icon,
                contentDescription = title,
                tint = if (isSelected) Color(0xFF10251D) else Color(0xFFD1D1D6),
                modifier = Modifier.size(14.dp)
            )
            Spacer(modifier = Modifier.width(4.dp))
            Text(
                text = title,
                fontSize = 11.sp,
                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                color = if (isSelected) Color(0xFF10251D) else Color(0xFFD1D1D6)
            )
        }
    }
}

@Composable
private fun WorkspaceCanvas(
    viewMode: EditorViewMode,
    source: String,
    docName: String,
    viewerDevice: ViewerDevice,
    viewerZoom: Float,
    onSourceChange: (String) -> Unit,
    onDeviceChange: (ViewerDevice) -> Unit,
    onZoomChange: (Float) -> Unit,
    modifier: Modifier = Modifier
) {
    when (viewMode) {
        EditorViewMode.CODE -> {
            CodeEditorView(source = source, onSourceChange = onSourceChange, modifier = modifier)
        }
        EditorViewMode.HTML_VIEWER -> {
            HtmlViewerPane(
                html = source,
                device = viewerDevice,
                zoom = viewerZoom,
                onDeviceChange = onDeviceChange,
                onZoomChange = onZoomChange,
                modifier = modifier
            )
        }
        EditorViewMode.SPLIT -> {
            Row(modifier = modifier.fillMaxSize()) {
                Box(modifier = Modifier.weight(1f).fillMaxHeight()) {
                    CodeEditorView(source = source, onSourceChange = onSourceChange)
                }
                Box(modifier = Modifier.width(1.dp).fillMaxHeight().background(Color(0xFF2C2C33)))
                Box(modifier = Modifier.weight(1f).fillMaxHeight()) {
                    HtmlViewerPane(
                        html = source,
                        device = viewerDevice,
                        zoom = viewerZoom,
                        onDeviceChange = onDeviceChange,
                        onZoomChange = onZoomChange
                    )
                }
            }
        }
    }
}

@Composable
private fun CodeEditorView(
    source: String,
    onSourceChange: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    Column(modifier = modifier.fillMaxSize().padding(8.dp)) {
        OutlinedTextField(
            value = source,
            onValueChange = onSourceChange,
            modifier = Modifier.fillMaxSize().testTag("flux_html_input"),
            textStyle = MaterialTheme.typography.bodyMedium.copy(
                fontFamily = JetBrainsMono,
                fontSize = 12.5.sp,
                lineHeight = 18.sp,
                color = Color(0xFFECECF1)
            ),
            shape = RoundedCornerShape(8.dp),
            colors = OutlinedTextFieldDefaults.colors(
                focusedContainerColor = Color(0xFF141417),
                unfocusedContainerColor = Color(0xFF141417),
                focusedBorderColor = MintAccent.copy(alpha = 0.5f),
                unfocusedBorderColor = Color(0xFF2A2A33)
            )
        )
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun DockedInspectorPane(
    report: com.example.data.model.FluxReport?,
    docName: String,
    severityFilter: FindingSeverity?,
    activeCategory: AuditCategory,
    onSeveritySelect: (FindingSeverity?) -> Unit,
    onCategorySelect: (AuditCategory) -> Unit,
    onResolveFinding: (com.example.data.model.FluxFinding) -> Unit,
    onAutoFixFinding: (com.example.data.model.FluxFinding) -> Unit,
    onExportJson: () -> Unit,
    onExportCsv: () -> Unit,
    modifier: Modifier = Modifier
) {
    Column(modifier = modifier.fillMaxSize().padding(12.dp)) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(
                    text = "Audit Diagnostics",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = Color.White
                )
                Text(
                    text = "WCAG 2.1, SEO & Performance signals",
                    style = MaterialTheme.typography.bodySmall,
                    color = Color(0xFF9E9EA8)
                )
            }

            if (report != null) {
                Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    OutlinedButton(
                        onClick = onExportJson,
                        modifier = Modifier.testTag("export_json_btn"),
                        contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 8.dp, vertical = 2.dp)
                    ) {
                        Text("JSON", fontSize = 10.sp)
                    }
                    OutlinedButton(
                        onClick = onExportCsv,
                        modifier = Modifier.testTag("export_csv_btn"),
                        contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 8.dp, vertical = 2.dp)
                    ) {
                        Text("CSV", fontSize = 10.sp)
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        if (report == null) {
            Box(
                modifier = Modifier.fillMaxSize().border(1.dp, Color(0xFF2C2C33), RoundedCornerShape(10.dp)).padding(20.dp),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(Icons.Default.FactCheck, contentDescription = null, tint = MintAccent.copy(alpha = 0.6f), modifier = Modifier.size(36.dp))
                    Spacer(modifier = Modifier.height(8.dp))
                    Text("Ready to audit. Click 'Run Audit' above.", color = Color(0xFF9E9EA8), fontSize = 12.sp)
                }
            }
            return
        }

        ScoreCard(report = report)

        Spacer(modifier = Modifier.height(8.dp))

        // Severity filter chips
        FlowRow(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(4.dp),
            verticalArrangement = Arrangement.spacedBy(2.dp)
        ) {
            FilterChip(
                selected = severityFilter == null,
                onClick = { onSeveritySelect(null) },
                label = { Text("All (${report.applicableCount})", fontSize = 11.sp) }
            )
            FilterChip(
                selected = severityFilter == FindingSeverity.ERROR,
                onClick = { onSeveritySelect(FindingSeverity.ERROR) },
                label = { Text("Errors (${report.errorsCount})", fontSize = 11.sp) }
            )
            FilterChip(
                selected = severityFilter == FindingSeverity.WARNING,
                onClick = { onSeveritySelect(FindingSeverity.WARNING) },
                label = { Text("Warnings (${report.warningsCount})", fontSize = 11.sp) }
            )
            FilterChip(
                selected = severityFilter == FindingSeverity.PASS,
                onClick = { onSeveritySelect(FindingSeverity.PASS) },
                label = { Text("Passed (${report.passesCount})", fontSize = 11.sp) }
            )
        }

        Spacer(modifier = Modifier.height(6.dp))

        // Findings list
        val filtered = report.findings.filter { f ->
            (severityFilter == null || f.severity == severityFilter) &&
                    (activeCategory == AuditCategory.OVERVIEW || f.category == activeCategory)
        }

        if (filtered.isEmpty()) {
            Box(
                modifier = Modifier.fillMaxWidth().weight(1f).border(1.dp, Color(0xFF2C2C33), RoundedCornerShape(8.dp)).padding(16.dp),
                contentAlignment = Alignment.Center
            ) {
                Text("No findings in this view filter.", color = Color(0xFF9E9EA8), fontSize = 12.sp)
            }
        } else {
            LazyColumn(
                modifier = Modifier.fillMaxWidth().weight(1f),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(filtered, key = { it.id }) { finding ->
                    FindingCard(
                        finding = finding,
                        onResolveClick = { onResolveFinding(finding) },
                        onAutoFixClick = { onAutoFixFinding(finding) },
                        onCopyFix = {}
                    )
                }
            }
        }
    }
}
