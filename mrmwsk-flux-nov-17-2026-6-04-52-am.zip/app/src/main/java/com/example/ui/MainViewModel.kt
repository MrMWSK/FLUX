package com.example.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.local.AppDatabase
import com.example.data.model.AuditCategory
import com.example.data.model.EnglishFontFamily
import com.example.data.model.FindingSeverity
import com.example.data.model.FluxFinding
import com.example.data.model.FluxReport
import com.example.data.model.LanguageFilter
import com.example.data.model.ReaderAccent
import com.example.data.model.ReaderSettings
import com.example.data.model.ReadingTheme
import com.example.data.model.SampleDocuments
import com.example.data.model.SavedDocument
import com.example.data.model.UrduFontFamily
import com.example.data.repository.DocumentRepository
import com.example.domain.FluxEngine
import com.example.domain.OpenLeafEngine
import com.example.domain.OpenLeafParseResult
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

enum class AppDestination {
    FLUX_AUDIT,
    LIBRARY,
    EXPORT_HELP
}

enum class EditorViewMode {
    CODE,
    HTML_VIEWER,
    SPLIT
}

enum class ViewerDevice(val label: String, val widthDp: Int?) {
    MOBILE("Mobile (375dp)", 375),
    TABLET("Tablet (768dp)", 768),
    DESKTOP("Desktop (Fluid)", null)
}

data class UiFeedback(
    val message: String,
    val isError: Boolean = false
)

class MainViewModel(application: Application) : AndroidViewModel(application) {

    private val repository: DocumentRepository

    init {
        val database = AppDatabase.getDatabase(application)
        repository = DocumentRepository(database.documentDao())
        initDefaultLibraryIfEmpty()
    }

    // Top Navigation
    private val _currentDestination = MutableStateFlow(AppDestination.FLUX_AUDIT)
    val currentDestination: StateFlow<AppDestination> = _currentDestination.asStateFlow()

    fun navigateTo(destination: AppDestination) {
        _currentDestination.value = destination
    }

    // UI Feedback
    private val _uiFeedback = MutableStateFlow<UiFeedback?>(null)
    val uiFeedback: StateFlow<UiFeedback?> = _uiFeedback.asStateFlow()

    fun showFeedback(message: String, isError: Boolean = false) {
        _uiFeedback.value = UiFeedback(message, isError)
    }

    fun clearFeedback() {
        _uiFeedback.value = null
    }

    // ==========================================
    // MrMWSK FLUX — Studio State
    // ==========================================
    private val _fluxSource = MutableStateFlow(SampleDocuments.FLUX_TEST_SAMPLE)
    val fluxSource: StateFlow<String> = _fluxSource.asStateFlow()

    private val _fluxPreviousSource = MutableStateFlow<String?>(null)
    val fluxPreviousSource: StateFlow<String?> = _fluxPreviousSource.asStateFlow()

    private val _fluxDocumentName = MutableStateFlow("index.html")
    val fluxDocumentName: StateFlow<String> = _fluxDocumentName.asStateFlow()

    private val _fluxReport = MutableStateFlow<FluxReport?>(null)
    val fluxReport: StateFlow<FluxReport?> = _fluxReport.asStateFlow()

    private val _fluxSeverityFilter = MutableStateFlow<FindingSeverity?>(null)
    val fluxSeverityFilter: StateFlow<FindingSeverity?> = _fluxSeverityFilter.asStateFlow()

    private val _fluxAuditCategory = MutableStateFlow(AuditCategory.OVERVIEW)
    val fluxAuditCategory: StateFlow<AuditCategory> = _fluxAuditCategory.asStateFlow()

    private val _fluxTargetLanguage = MutableStateFlow("en")
    val fluxTargetLanguage: StateFlow<String> = _fluxTargetLanguage.asStateFlow()

    private val _isAnalyzingFlux = MutableStateFlow(false)
    val isAnalyzingFlux: StateFlow<Boolean> = _isAnalyzingFlux.asStateFlow()

    // Adobe-style Editor & Viewer View Modes
    private val _editorViewMode = MutableStateFlow(EditorViewMode.CODE)
    val editorViewMode: StateFlow<EditorViewMode> = _editorViewMode.asStateFlow()

    private val _viewerDevice = MutableStateFlow(ViewerDevice.DESKTOP)
    val viewerDevice: StateFlow<ViewerDevice> = _viewerDevice.asStateFlow()

    private val _viewerZoom = MutableStateFlow(1.0f)
    val viewerZoom: StateFlow<Float> = _viewerZoom.asStateFlow()

    // Guided Error Resolution Modal State
    private val _activeFindingForResolution = MutableStateFlow<FluxFinding?>(null)
    val activeFindingForResolution: StateFlow<FluxFinding?> = _activeFindingForResolution.asStateFlow()

    fun setEditorViewMode(mode: EditorViewMode) {
        _editorViewMode.value = mode
    }

    fun setViewerDevice(device: ViewerDevice) {
        _viewerDevice.value = device
    }

    fun setViewerZoom(zoom: Float) {
        _viewerZoom.value = zoom.coerceIn(0.75f, 1.75f)
    }

    fun openFindingResolution(finding: FluxFinding) {
        _activeFindingForResolution.value = finding
    }

    fun closeFindingResolution() {
        _activeFindingForResolution.value = null
    }

    fun setFluxSource(content: String, fileName: String = "index.html") {
        _fluxSource.value = content
        _fluxDocumentName.value = fileName
        runFluxCheck(content)
    }

    fun setTargetLanguage(lang: String) {
        _fluxTargetLanguage.value = lang
    }

    fun runFluxCheck(source: String = _fluxSource.value) {
        viewModelScope.launch {
            _isAnalyzingFlux.value = true
            withContext(Dispatchers.Default) {
                val report = FluxEngine.analyzeHtml(source)
                _fluxReport.value = report
            }
            _isAnalyzingFlux.value = false
        }
    }

    fun applyFluxSafeFixes() {
        val current = _fluxSource.value
        if (current.isBlank()) return
        _fluxPreviousSource.value = current
        val fixed = FluxEngine.applySafeFixes(current, _fluxTargetLanguage.value)
        _fluxSource.value = fixed
        runFluxCheck(fixed)
        showFeedback("All safe fixes applied (charset, viewport, lang, images & noopener)!")
    }

    fun resolveSpecificFinding(finding: FluxFinding) {
        val current = _fluxSource.value
        if (current.isBlank()) return
        _fluxPreviousSource.value = current
        val fixed = FluxEngine.resolveSpecificFinding(current, finding, _fluxTargetLanguage.value)
        _fluxSource.value = fixed
        runFluxCheck(fixed)
        _activeFindingForResolution.value = null
        showFeedback("Applied fix for: ${finding.title}!")
    }

    fun undoFluxFixes() {
        val prev = _fluxPreviousSource.value
        if (prev != null) {
            _fluxSource.value = prev
            _fluxPreviousSource.value = null
            runFluxCheck(prev)
            showFeedback("Undid previous changes")
        }
    }

    fun setFluxSeverityFilter(severity: FindingSeverity?) {
        _fluxSeverityFilter.value = severity
    }

    fun setFluxAuditCategory(category: AuditCategory) {
        _fluxAuditCategory.value = category
    }

    fun clearFlux() {
        _fluxPreviousSource.value = _fluxSource.value
        _fluxSource.value = ""
        _fluxReport.value = null
        _fluxDocumentName.value = "untitled.html"
    }

    fun loadFluxSample(sampleIndex: Int = 0) {
        val sample = when (sampleIndex) {
            0 -> Pair(SampleDocuments.FLUX_TEST_SAMPLE, "flux_accessibility_test.html")
            1 -> Pair(SampleDocuments.CLEAN_COMPLIANT_ARTICLE, "clean_offline_guide.html")
            else -> Pair(SampleDocuments.OPENLEAF_MULTILINGUAL_SAMPLE, "mrmwsk_multilingual_poetry.html")
        }
        setFluxSource(sample.first, sample.second)
        showFeedback("Loaded sample: ${sample.second}")
    }

    fun formatHtmlSource() {
        val current = _fluxSource.value
        if (current.isBlank()) return
        val doc = org.jsoup.Jsoup.parse(current)
        doc.outputSettings().indentAmount(2)
        val formatted = "<!doctype html>\n" + doc.outerHtml()
        _fluxSource.value = formatted
        showFeedback("Formatted HTML code cleanly")
    }

    // ==========================================
    // Save As and Library State
    // ==========================================
    private val _searchQuery = MutableStateFlow("")
    val searchQuery: StateFlow<String> = _searchQuery.asStateFlow()

    val savedDocuments: StateFlow<List<SavedDocument>> = combine(
        repository.allDocuments,
        _searchQuery
    ) { docs, query ->
        if (query.isBlank()) {
            docs
        } else {
            docs.filter {
                it.title.contains(query, ignoreCase = true) ||
                        it.fileName.contains(query, ignoreCase = true)
            }
        }
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    fun setSearchQuery(query: String) {
        _searchQuery.value = query
    }

    fun saveAsDocument(customTitle: String, customFileName: String) {
        val raw = _fluxSource.value
        if (raw.isBlank()) {
            showFeedback("Cannot save empty document", isError = true)
            return
        }
        viewModelScope.launch {
            withContext(Dispatchers.Default) {
                val report = FluxEngine.analyzeHtml(raw)
                val clean = FluxEngine.applySafeFixes(raw, _fluxTargetLanguage.value)
                val parsed = OpenLeafEngine.parse(raw)
                val sanitizedFileName = if (customFileName.endsWith(".html", ignoreCase = true)) customFileName else "$customFileName.html"
                val doc = SavedDocument(
                    title = customTitle.ifBlank { sanitizedFileName },
                    fileName = sanitizedFileName,
                    rawHtml = raw,
                    cleanedHtml = clean,
                    fluxScore = report.score,
                    errorsCount = report.errorsCount,
                    warningsCount = report.warningsCount,
                    urduCount = parsed.stats.urduSectionsCount,
                    romanCount = parsed.stats.romanUrduSectionsCount,
                    englishCount = parsed.stats.englishSectionsCount,
                    wordCount = parsed.stats.wordCount
                )
                repository.insert(doc)
                _fluxDocumentName.value = sanitizedFileName
            }
            showFeedback("Saved as \"$customFileName\" in Library!")
        }
    }

    fun openDocumentFromLibrary(doc: SavedDocument) {
        setFluxSource(doc.rawHtml, doc.fileName)
        _currentDestination.value = AppDestination.FLUX_AUDIT
        showFeedback("Loaded \"${doc.title}\"")
    }

    fun deleteDocument(doc: SavedDocument) {
        viewModelScope.launch {
            repository.delete(doc)
            showFeedback("Deleted from Library")
        }
    }

    fun toggleFavorite(doc: SavedDocument) {
        viewModelScope.launch {
            repository.setFavorite(doc.id, !doc.isFavorite)
        }
    }

    private fun initDefaultLibraryIfEmpty() {
        viewModelScope.launch {
            val count = repository.count()
            if (count == 0) {
                val sample = SampleDocuments.FLUX_TEST_SAMPLE
                val parsed = OpenLeafEngine.parse(sample)
                val report = FluxEngine.analyzeHtml(sample)
                repository.insert(
                    SavedDocument(
                        title = "MrMWSK FLUX Test Suite",
                        fileName = "flux_accessibility_test.html",
                        rawHtml = sample,
                        cleanedHtml = FluxEngine.applySafeFixes(sample, "en"),
                        fluxScore = report.score,
                        errorsCount = report.errorsCount,
                        warningsCount = report.warningsCount,
                        urduCount = 0,
                        romanCount = 0,
                        englishCount = parsed.stats.englishSectionsCount,
                        wordCount = parsed.stats.wordCount,
                        isFavorite = true
                    )
                )
            }
            runFluxCheck(_fluxSource.value)
        }
    }
}
