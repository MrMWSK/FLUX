package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Primary Brand Palette: Forest Green, Emerald & Sage Mint
val EmeraldDark = Color(0xFF10251D)
val EmeraldMedium = Color(0xFF174D34)
val ForestGreen = Color(0xFF16734A)
val MintPrimary = Color(0xFF26945B)
val MintAccent = Color(0xFF8FE0AE)
val MintLight = Color(0xFFE5F4EB)
val MintSoft = Color(0xFFDFF1E5)

// Functional & Severity Colors
val ErrorRed = Color(0xFFB42318)
val ErrorRedBg = Color(0xFFFFF0EE)
val WarningAmber = Color(0xFF946200)
val WarningAmberBorder = Color(0xFFD39A17)
val WarningAmberBg = Color(0xFFFFF7DF)
val PassGreen = Color(0xFF1E824C)
val PassGreenBg = Color(0xFFE8F6ED)

// Neutral & Reading Palettes
// Light Theme
val BgLight = Color(0xFFF4F7F5)
val SurfaceLight = Color(0xFFFFFFFF)
val SurfaceVariantLight = Color(0xFFEBF1ED)
val TextDark = Color(0xFF14241B)
val TextMuted = Color(0xFF5E6D64)
val BorderLight = Color(0xFFD3DFD7)

// Dark Theme
val BgDark = Color(0xFF0F1713)
val SurfaceDark = Color(0xFF16221B)
val SurfaceVariantDark = Color(0xFF1D2C24)
val TextLight = Color(0xFFEAF2ED)
val TextMutedDark = Color(0xFFA2B4AA)
val BorderDark = Color(0xFF2E4035)

// Sepia Reading Theme
val SepiaBg = Color(0xFFEEE5D3)
val SepiaSurface = Color(0xFFFBF2DF)
val SepiaText = Color(0xFF433729)
val SepiaMuted = Color(0xFF796B58)
val SepiaBorder = Color(0xFFD9CBB4)
val SepiaAccent = Color(0xFF6F5131)
