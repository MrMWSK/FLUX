package com.example.ui.components

import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.DesktopWindows
import androidx.compose.material.icons.filled.Devices
import androidx.compose.material.icons.filled.PhoneAndroid
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.TabletMac
import androidx.compose.material.icons.filled.ZoomIn
import androidx.compose.material.icons.filled.ZoomOut
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import com.example.ui.ViewerDevice

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun HtmlViewerPane(
    html: String,
    device: ViewerDevice,
    zoom: Float,
    onDeviceChange: (ViewerDevice) -> Unit,
    onZoomChange: (Float) -> Unit,
    modifier: Modifier = Modifier
) {
    var webViewInstance by remember { mutableStateOf<WebView?>(null) }
    var showDeviceBezel by remember { mutableStateOf(true) }
    var reloadTrigger by remember { mutableIntStateOf(0) }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(Color(0xFF18181B))
            .testTag("html_viewer_pane")
    ) {
        // Control Toolbar for Viewport Definition
        Surface(
            modifier = Modifier.fillMaxWidth(),
            color = Color(0xFF27272A),
            tonalElevation = 2.dp,
            border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF3F3F46))
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 12.dp, vertical = 8.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Viewport selection chips
                FlowRow(
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    verticalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    FilterChip(
                        selected = device == ViewerDevice.MOBILE,
                        onClick = { onDeviceChange(ViewerDevice.MOBILE) },
                        leadingIcon = { Icon(Icons.Default.PhoneAndroid, contentDescription = null, modifier = Modifier.size(16.dp)) },
                        label = { Text("Phone (375px)") },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = MaterialTheme.colorScheme.primaryContainer,
                            selectedLabelColor = MaterialTheme.colorScheme.onPrimaryContainer
                        )
                    )

                    FilterChip(
                        selected = device == ViewerDevice.TABLET,
                        onClick = { onDeviceChange(ViewerDevice.TABLET) },
                        leadingIcon = { Icon(Icons.Default.TabletMac, contentDescription = null, modifier = Modifier.size(16.dp)) },
                        label = { Text("Tablet (768px)") },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = MaterialTheme.colorScheme.primaryContainer,
                            selectedLabelColor = MaterialTheme.colorScheme.onPrimaryContainer
                        )
                    )

                    FilterChip(
                        selected = device == ViewerDevice.DESKTOP,
                        onClick = { onDeviceChange(ViewerDevice.DESKTOP) },
                        leadingIcon = { Icon(Icons.Default.DesktopWindows, contentDescription = null, modifier = Modifier.size(16.dp)) },
                        label = { Text("Desktop (Fluid)") },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = MaterialTheme.colorScheme.primaryContainer,
                            selectedLabelColor = MaterialTheme.colorScheme.onPrimaryContainer
                        )
                    )
                }

                // Zoom & Refresh controls
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    IconButton(
                        onClick = { onZoomChange((zoom - 0.25f).coerceAtLeast(0.75f)) },
                        modifier = Modifier.size(32.dp).testTag("zoom_out_btn")
                    ) {
                        Icon(Icons.Default.ZoomOut, contentDescription = "Zoom Out", tint = Color.White, modifier = Modifier.size(18.dp))
                    }

                    Text(
                        text = "${(zoom * 100).toInt()}%",
                        color = Color.White,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(horizontal = 4.dp)
                    )

                    IconButton(
                        onClick = { onZoomChange((zoom + 0.25f).coerceAtMost(1.75f)) },
                        modifier = Modifier.size(32.dp).testTag("zoom_in_btn")
                    ) {
                        Icon(Icons.Default.ZoomIn, contentDescription = "Zoom In", tint = Color.White, modifier = Modifier.size(18.dp))
                    }

                    IconButton(
                        onClick = {
                            reloadTrigger++
                            webViewInstance?.loadDataWithBaseURL(null, html, "text/html", "UTF-8", null)
                        },
                        modifier = Modifier.size(32.dp).testTag("reload_webview_btn")
                    ) {
                        Icon(Icons.Default.Refresh, contentDescription = "Reload View", tint = Color.White, modifier = Modifier.size(18.dp))
                    }
                }
            }
        }

        // Live Render Canvas
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(if (device.widthDp != null) 16.dp else 0.dp),
            contentAlignment = Alignment.TopCenter
        ) {
            val contentModifier = if (device.widthDp != null) {
                Modifier
                    .width(device.widthDp.dp)
                    .fillMaxHeight()
                    .clip(RoundedCornerShape(20.dp))
                    .border(6.dp, Color(0xFF27272A), RoundedCornerShape(20.dp))
                    .background(Color.White)
            } else {
                Modifier
                    .fillMaxSize()
                    .background(Color.White)
            }

            Box(modifier = contentModifier) {
                AndroidView(
                    factory = { ctx ->
                        WebView(ctx).apply {
                            webViewClient = WebViewClient()
                            this.settings.javaScriptEnabled = false
                            this.settings.allowFileAccess = false
                            this.settings.allowContentAccess = false
                            this.settings.textZoom = (zoom * 100).toInt()
                            loadDataWithBaseURL(null, html, "text/html", "UTF-8", null)
                            webViewInstance = this
                        }
                    },
                    update = { view ->
                        view.settings.textZoom = (zoom * 100).toInt()
                        view.loadDataWithBaseURL(null, html, "text/html", "UTF-8", null)
                    },
                    modifier = Modifier.fillMaxSize()
                )

                // Mobile/Tablet device camera notch indicator
                if (device.widthDp != null && showDeviceBezel) {
                    Box(
                        modifier = Modifier
                            .align(Alignment.TopCenter)
                            .padding(top = 4.dp)
                            .size(width = 60.dp, height = 6.dp)
                            .clip(RoundedCornerShape(99.dp))
                            .background(Color(0xFF27272A).copy(alpha = 0.8f))
                    )
                }
            }
        }
    }
}
