package com.example.ui.about

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Android
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.FactCheck
import androidx.compose.material.icons.filled.FolderZip
import androidx.compose.material.icons.filled.MenuBook
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.VerifiedUser
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.EmeraldDark
import com.example.ui.theme.MintAccent
import com.example.ui.theme.MintLight
import com.example.ui.theme.PassGreen

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun AboutScreen(
    modifier: Modifier = Modifier
) {
    val scrollState = rememberScrollState()

    Column(
        modifier = modifier
            .fillMaxSize()
            .verticalScroll(scrollState)
            .testTag("about_screen")
    ) {
        // Header
        Surface(
            modifier = Modifier.fillMaxWidth(),
            color = EmeraldDark,
            tonalElevation = 4.dp
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 18.dp, vertical = 18.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = "MrMWSK ",
                        fontSize = 22.sp,
                        fontWeight = FontWeight.Black,
                        color = Color.White
                    )
                    Text(
                        text = "Studio",
                        fontSize = 22.sp,
                        fontWeight = FontWeight.Black,
                        color = MintAccent
                    )
                }
                Text(
                    text = "All-In-One Offline HTML Quality Audit & Multilingual Reader",
                    fontSize = 13.sp,
                    color = MintLight.copy(alpha = 0.85f)
                )

                Spacer(modifier = Modifier.height(10.dp))

                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(999.dp))
                        .border(1.dp, MintAccent.copy(alpha = 0.45f), RoundedCornerShape(999.dp))
                        .padding(horizontal = 12.dp, vertical = 6.dp)
                ) {
                    Text(
                        text = "100% OFFLINE · ZERO TELEMETRY · PRIVACY-FIRST",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = MintAccent
                    )
                }
            }
        }

        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // APK & ZIP Export Guide Card
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(
                    containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.4f)
                ),
                border = androidx.compose.foundation.BorderStroke(1.5.dp, MaterialTheme.colorScheme.primary)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Icon(
                            Icons.Default.Android,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(28.dp)
                        )
                        Text(
                            text = "Download Installable APK & Source ZIP",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    Text(
                        text = "You can download the compiled APK file and the complete project ZIP archive directly from Google AI Studio:",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurface
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    ExportStepRow(
                        number = "1",
                        title = "Get Installable APK",
                        desc = "Click the top-right Settings/Menu icon in the AI Studio header and choose 'Download APK' or use the build outputs. You can also build via command line: gradle assembleDebug."
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    ExportStepRow(
                        number = "2",
                        title = "Get Full Project ZIP",
                        desc = "In the AI Studio menu, click 'Download Project as ZIP' or 'Export ZIP'. You will receive the entire production-ready Android codebase."
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    ExportStepRow(
                        number = "3",
                        title = "Install on Any Device",
                        desc = "Transfer the .apk to any Android phone, tablet, or foldable (Android 7.0 / SDK 24 through Android 15 / SDK 36) to install and use 100% offline."
                    )
                }
            }

            // Suite Features
            Text(
                text = "MrMWSK Combined Suite Features",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold
            )

            FeatureCard(
                icon = Icons.Default.FactCheck,
                title = "MrMWSK FLUX — HTML Audit Studio",
                bullets = listOf(
                    "Heuristic WCAG 2.1 accessibility & conformance audit",
                    "SEO checks: title, meta description, H1 hierarchy, OpenGraph",
                    "Performance checks: lazy loading, viewport, rel=noopener",
                    "Category score gauges & progress bars (0-100)",
                    "Deterministic Safe Fixes with target language picker (English, Urdu, Arabic, Spanish, etc.)",
                    "Undo fixes and export findings as JSON or CSV reports"
                )
            )

            FeatureCard(
                icon = Icons.Default.MenuBook,
                title = "MrMWSK Reader Studio",
                bullets = listOf(
                    "Sanitizes active scripts and frames for completely private local reading",
                    "Multi-language segmentation: All Content, Urdu (اردو), Roman Urdu, and English",
                    "Independent typography sliders for Urdu and English (fonts, sizes, line spacing)",
                    "Focus Mode for distraction-free reading with one-tap exit",
                    "Reading Themes: Clean Paper Light, Warm Sepia Parchment, Midnight Dark",
                    "Auto-extracted Table of Contents (TOC) with smooth section jumping"
                )
            )

            FeatureCard(
                icon = Icons.Default.Security,
                title = "100% Offline & Universal Compatibility",
                bullets = listOf(
                    "Backed by local Room Database for persisting documents and audit scores",
                    "Responsive Canonical Layouts for phones, foldables, and wide tablets",
                    "Zero external API dependencies — never transmits code to external servers",
                    "Full RTL (Right-to-Left) Arabic and Nastaliq Urdu layout support"
                )
            )
        }
    }
}

@Composable
private fun ExportStepRow(
    number: String,
    title: String,
    desc: String
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        Box(
            modifier = Modifier
                .size(24.dp)
                .clip(CircleShape)
                .background(MaterialTheme.colorScheme.primary),
            contentAlignment = Alignment.Center
        ) {
            Text(
                text = number,
                color = Color.White,
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold
            )
        }
        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = title,
                fontSize = 13.sp,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onSurface
            )
            Text(
                text = desc,
                fontSize = 12.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}

@Composable
private fun FeatureCard(
    icon: ImageVector,
    title: String,
    bullets: List<String>
) {
    Surface(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(14.dp),
        color = MaterialTheme.colorScheme.surface,
        tonalElevation = 1.dp,
        border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.35f))
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Icon(icon, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                Text(
                    text = title,
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurface
                )
            }
            Spacer(modifier = Modifier.height(8.dp))
            bullets.forEach { bullet ->
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 3.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Icon(
                        Icons.Default.CheckCircle,
                        contentDescription = null,
                        tint = PassGreen,
                        modifier = Modifier.size(16.dp)
                    )
                    Text(
                        text = bullet,
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }
    }
}
