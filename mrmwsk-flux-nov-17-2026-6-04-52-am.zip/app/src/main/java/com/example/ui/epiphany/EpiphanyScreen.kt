package com.example.ui.epiphany

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.FileUpload
import androidx.compose.material.icons.filled.FormatSize
import androidx.compose.material.icons.filled.Fullscreen
import androidx.compose.material.icons.filled.FullscreenExit
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material.icons.filled.MenuBook
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.Web
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import com.example.data.model.EnglishFontFamily
import com.example.data.model.LanguageFilter
import com.example.data.model.ReaderAccent
import com.example.data.model.ReaderSettings
import com.example.data.model.ReadingTheme
import com.example.data.model.SampleDocuments
import com.example.data.model.TocItem
import com.example.data.model.UrduFontFamily
import com.example.domain.OpenLeafEngine
import com.example.domain.OpenLeafParseResult
import com.example.domain.RenderBlock
import com.example.ui.theme.EmeraldDark
import com.example.ui.theme.JetBrainsMono
import com.example.ui.theme.LoraSerif
import com.example.ui.theme.MintAccent
import com.example.ui.theme.MintLight
import com.example.ui.theme.PlusJakartaSans
import com.example.ui.theme.SepiaBg
import com.example.ui.theme.SepiaBorder
import com.example.ui.theme.SepiaMuted
import com.example.ui.theme.SepiaSurface
import com.example.ui.theme.SepiaText
import kotlinx.coroutines.launch

@OptIn(ExperimentalLayoutApi::class, ExperimentalMaterial3Api::class)
@Composable
fun EpiphanyScreen(
    modifier: Modifier = Modifier,
    initialHtml: String? = null,
    initialTitle: String? = null
) {
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()
    val listState = rememberLazyListState()

    val startingHtml = initialHtml ?: SampleDocuments.OPENLEAF_MULTILINGUAL_SAMPLE
    val startingTitle = initialTitle ?: if (initialHtml != null) "Imported Document" else "MrMWSK Diwan"

    var docTitle by remember { mutableStateOf(startingTitle) }
    var rawHtml by remember { mutableStateOf(startingHtml) }
    var parseResult by remember { mutableStateOf(OpenLeafEngine.parse(startingHtml)) }
    var settings by remember { mutableStateOf(ReaderSettings()) }
    var isWebPreview by remember { mutableStateOf(false) }

    var showTypographySheet by remember { mutableStateOf(false) }
    var showTocSheet by remember { mutableStateOf(false) }
    var sampleMenuExpanded by remember { mutableStateOf(false) }

    val filePickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent()
    ) { uri: Uri? ->
        if (uri != null) {
            try {
                context.contentResolver.openInputStream(uri)?.use { stream ->
                    val text = stream.bufferedReader().use { it.readText() }
                    val name = uri.lastPathSegment?.substringAfterLast("/") ?: "epiphany_document.html"
                    rawHtml = text
                    docTitle = name
                    parseResult = OpenLeafEngine.parse(text)
                }
            } catch (e: Exception) {
                // handle error
            }
        }
    }

    fun shareCleaned(content: String, title: String) {
        val sendIntent = Intent().apply {
            action = Intent.ACTION_SEND
            putExtra(Intent.EXTRA_TEXT, content)
            putExtra(Intent.EXTRA_TITLE, title)
            type = "text/html"
        }
        context.startActivity(Intent.createChooser(sendIntent, "Export Cleaned HTML"))
    }

    val (canvasBg, canvasSurface, canvasText, canvasMuted, canvasBorder) = when (settings.theme) {
        ReadingTheme.LIGHT -> Quintuple(Color(0xFFF4F2ED), Color(0xFFFFFEFA), Color(0xFF20231F), Color(0xFF687067), Color(0xFFDEDED5))
        ReadingTheme.SEPIA -> Quintuple(SepiaBg, SepiaSurface, SepiaText, SepiaMuted, SepiaBorder)
        ReadingTheme.DARK -> Quintuple(Color(0xFF151A17), Color(0xFF202722), Color(0xFFE8EEE9), Color(0xFFAAB6AE), Color(0xFF3C4840))
    }

    val accentColor = Color(settings.accent.hexColor)

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(canvasBg)
            .testTag("epiphany_screen")
    ) {
        Column(modifier = Modifier.fillMaxSize()) {
            if (!settings.isFocusMode) {
                // Header: MrMWSK EPIPHANY
                Surface(
                    modifier = Modifier.fillMaxWidth(),
                    color = EmeraldDark,
                    tonalElevation = 4.dp
                ) {
                    Column(modifier = Modifier.fillMaxWidth().padding(horizontal = 18.dp, vertical = 14.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Text(
                                        text = "MrMWSK ",
                                        fontSize = 19.sp,
                                        fontWeight = FontWeight.Black,
                                        color = Color.White
                                    )
                                    Text(
                                        text = "EPIPHANY",
                                        fontSize = 19.sp,
                                        fontWeight = FontWeight.Black,
                                        color = MintAccent
                                    )
                                }
                                Text(
                                    text = "Multilingual Literature & Document Studio",
                                    fontSize = 12.sp,
                                    color = MintLight.copy(alpha = 0.85f)
                                )
                            }

                            Button(
                                onClick = { settings = settings.copy(isFocusMode = true) },
                                colors = ButtonDefaults.buttonColors(containerColor = accentColor),
                                modifier = Modifier.testTag("epiphany_focus_mode_btn")
                            ) {
                                Icon(Icons.Default.Fullscreen, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("Focus Mode")
                            }
                        }
                    }
                }

                // Controls & Toolbar
                Surface(
                    modifier = Modifier.fillMaxWidth(),
                    color = canvasSurface,
                    tonalElevation = 2.dp,
                    border = androidx.compose.foundation.BorderStroke(1.dp, canvasBorder)
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        val stats = parseResult.stats
                        FlowRow(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            verticalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            FilterChip(
                                selected = settings.activeFilter == LanguageFilter.ALL,
                                onClick = { settings = settings.copy(activeFilter = LanguageFilter.ALL) },
                                label = { Text("All Content") }
                            )
                            FilterChip(
                                selected = settings.activeFilter == LanguageFilter.URDU,
                                onClick = { settings = settings.copy(activeFilter = LanguageFilter.URDU) },
                                label = { Text("اردو Urdu (${stats.urduSectionsCount})") },
                                enabled = stats.urduSectionsCount > 0
                            )
                            FilterChip(
                                selected = settings.activeFilter == LanguageFilter.ROMAN_URDU,
                                onClick = { settings = settings.copy(activeFilter = LanguageFilter.ROMAN_URDU) },
                                label = { Text("Roman Urdu (${stats.romanUrduSectionsCount})") },
                                enabled = stats.romanUrduSectionsCount > 0
                            )
                            FilterChip(
                                selected = settings.activeFilter == LanguageFilter.ENGLISH,
                                onClick = { settings = settings.copy(activeFilter = LanguageFilter.ENGLISH) },
                                label = { Text("English (${stats.englishSectionsCount})") },
                                enabled = stats.englishSectionsCount > 0
                            )

                            Spacer(modifier = Modifier.weight(1f))

                            OutlinedButton(
                                onClick = { showTypographySheet = true },
                                modifier = Modifier.testTag("epiphany_typography_btn")
                            ) {
                                Icon(Icons.Default.FormatSize, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("Typography")
                            }

                            OutlinedButton(
                                onClick = { isWebPreview = !isWebPreview },
                                modifier = Modifier.testTag("epiphany_toggle_preview_btn")
                            ) {
                                Icon(if (isWebPreview) Icons.Default.MenuBook else Icons.Default.Web, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(if (isWebPreview) "Native View" else "Web View")
                            }

                            Box {
                                OutlinedButton(onClick = { sampleMenuExpanded = true }) {
                                    Text("Samples ▾")
                                }
                                DropdownMenu(expanded = sampleMenuExpanded, onDismissRequest = { sampleMenuExpanded = false }) {
                                    DropdownMenuItem(
                                        text = { Text("Ghalib & Iqbal Classical Verse") },
                                        onClick = {
                                            rawHtml = SampleDocuments.OPENLEAF_MULTILINGUAL_SAMPLE
                                            docTitle = "MrMWSK Diwan"
                                            parseResult = OpenLeafEngine.parse(rawHtml)
                                            sampleMenuExpanded = false
                                        }
                                    )
                                    DropdownMenuItem(
                                        text = { Text("Offline Architectural Guide") },
                                        onClick = {
                                            rawHtml = SampleDocuments.CLEAN_COMPLIANT_ARTICLE
                                            docTitle = "Offline Guide"
                                            parseResult = OpenLeafEngine.parse(rawHtml)
                                            sampleMenuExpanded = false
                                        }
                                    )
                                }
                            }

                            IconButton(onClick = { filePickerLauncher.launch("text/html") }) {
                                Icon(Icons.Default.FileUpload, contentDescription = "Open File", tint = accentColor)
                            }

                            IconButton(onClick = { shareCleaned(parseResult.cleanedHtml, docTitle) }) {
                                Icon(Icons.Default.Share, contentDescription = "Export Clean HTML", tint = accentColor)
                            }
                        }

                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "Reading: $docTitle · ${stats.wordCount} words · ~${stats.readingTimeMinutes} min",
                            fontSize = 12.sp,
                            color = canvasMuted
                        )
                    }
                }
            }

            // Canvas & TOC
            BoxWithConstraints(modifier = Modifier.fillMaxSize()) {
                val isTablet = maxWidth >= 840.dp && !settings.isFocusMode

                if (isTablet) {
                    Row(
                        modifier = Modifier.fillMaxSize().padding(16.dp),
                        horizontalArrangement = Arrangement.spacedBy(16.dp)
                    ) {
                        Surface(
                            modifier = Modifier.width(280.dp).fillMaxHeight(),
                            shape = RoundedCornerShape(16.dp),
                            color = canvasSurface,
                            border = androidx.compose.foundation.BorderStroke(1.dp, canvasBorder)
                        ) {
                            EpiphanyToc(
                                toc = parseResult.toc,
                                accentColor = accentColor,
                                onSelect = { item -> coroutineScope.launch { listState.animateScrollToItem(item.position) } }
                            )
                        }

                        Surface(
                            modifier = Modifier.weight(1f).fillMaxHeight(),
                            shape = RoundedCornerShape(16.dp),
                            color = canvasSurface,
                            border = androidx.compose.foundation.BorderStroke(1.dp, canvasBorder)
                        ) {
                            EpiphanyReadingCanvas(
                                parseResult = parseResult,
                                settings = settings,
                                isWebPreview = isWebPreview,
                                listState = listState,
                                canvasText = canvasText,
                                canvasBorder = canvasBorder,
                                accentColor = accentColor
                            )
                        }
                    }
                } else {
                    Box(modifier = Modifier.fillMaxSize()) {
                        EpiphanyReadingCanvas(
                            parseResult = parseResult,
                            settings = settings,
                            isWebPreview = isWebPreview,
                            listState = listState,
                            canvasText = canvasText,
                            canvasBorder = canvasBorder,
                            accentColor = accentColor,
                            modifier = Modifier.padding(if (settings.isFocusMode) 20.dp else 12.dp)
                        )

                        if (!settings.isFocusMode && parseResult.toc.isNotEmpty()) {
                            Surface(
                                modifier = Modifier
                                    .align(Alignment.BottomEnd)
                                    .padding(18.dp)
                                    .clickable { showTocSheet = true },
                                shape = CircleShape,
                                color = accentColor,
                                tonalElevation = 6.dp
                            ) {
                                Row(
                                    modifier = Modifier.padding(horizontal = 14.dp, vertical = 10.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Icon(Icons.Default.Menu, contentDescription = "TOC", tint = Color.White, modifier = Modifier.size(18.dp))
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text("TOC", color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                    }
                }
            }
        }

        // Floating Exit Focus Mode button
        if (settings.isFocusMode) {
            Surface(
                modifier = Modifier
                    .align(Alignment.TopEnd)
                    .padding(18.dp)
                    .clickable { settings = settings.copy(isFocusMode = false) },
                shape = RoundedCornerShape(999.dp),
                color = accentColor,
                tonalElevation = 8.dp
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 14.dp, vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(Icons.Default.FullscreenExit, contentDescription = null, tint = Color.White, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Exit Focus", color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                }
            }
        }

        // Typography Bottom Sheet
        if (showTypographySheet) {
            ModalBottomSheet(
                onDismissRequest = { showTypographySheet = false },
                containerColor = canvasSurface
            ) {
                EpiphanyTypographySheet(
                    settings = settings,
                    accentColor = accentColor,
                    onSettingsChange = { settings = it },
                    onClose = { showTypographySheet = false }
                )
            }
        }

        // Mobile TOC Bottom Sheet
        if (showTocSheet) {
            ModalBottomSheet(
                onDismissRequest = { showTocSheet = false },
                containerColor = canvasSurface
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "Document Contents",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = canvasText
                    )
                    Spacer(modifier = Modifier.height(10.dp))
                    EpiphanyToc(
                        toc = parseResult.toc,
                        accentColor = accentColor,
                        onSelect = { item ->
                            coroutineScope.launch { listState.animateScrollToItem(item.position) }
                            showTocSheet = false
                        }
                    )
                }
            }
        }
    }
}

@Composable
private fun EpiphanyReadingCanvas(
    parseResult: OpenLeafParseResult,
    settings: ReaderSettings,
    isWebPreview: Boolean,
    listState: androidx.compose.foundation.lazy.LazyListState,
    canvasText: Color,
    canvasBorder: Color,
    accentColor: Color,
    modifier: Modifier = Modifier
) {
    if (isWebPreview) {
        AndroidView(
            factory = { ctx ->
                WebView(ctx).apply {
                    webViewClient = WebViewClient()
                    this.settings.javaScriptEnabled = false
                    loadDataWithBaseURL(null, parseResult.cleanedHtml, "text/html", "UTF-8", null)
                }
            },
            update = { webView ->
                webView.loadDataWithBaseURL(null, parseResult.cleanedHtml, "text/html", "UTF-8", null)
            },
            modifier = modifier.fillMaxSize()
        )
    } else {
        val filteredBlocks = OpenLeafEngine.filterBlocks(parseResult.blocks, settings.activeFilter)

        LazyColumn(
            state = listState,
            modifier = modifier.fillMaxSize().padding(horizontal = 14.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            items(filteredBlocks, key = { it.id }) { block ->
                val isUrdu = block.detectedLang == "urdu" || block.isRtl
                val fontSize = if (isUrdu) settings.urduFontSizeSp else settings.englishFontSizeSp
                val lineSpacing = if (isUrdu) settings.urduLineSpacing else settings.englishLineSpacing

                val fontFamily = if (isUrdu) {
                    when (settings.urduFont) {
                        UrduFontFamily.NASTALIQ, UrduFontFamily.ARABIC -> LoraSerif
                        UrduFontFamily.SANS -> PlusJakartaSans
                    }
                } else {
                    when (settings.englishFont) {
                        EnglishFontFamily.SYSTEM -> PlusJakartaSans
                        EnglishFontFamily.SERIF -> LoraSerif
                        EnglishFontFamily.MONO -> JetBrainsMono
                    }
                }

                val textAlign = if (isUrdu) TextAlign.Right else TextAlign.Left

                when (block) {
                    is RenderBlock.Heading -> {
                        val headingSize = when (block.level) {
                            1 -> (fontSize * 1.55f).sp
                            2 -> (fontSize * 1.35f).sp
                            else -> (fontSize * 1.15f).sp
                        }
                        Text(
                            text = block.text,
                            fontSize = headingSize,
                            fontWeight = FontWeight.Bold,
                            fontFamily = fontFamily,
                            color = accentColor,
                            textAlign = textAlign,
                            modifier = Modifier.fillMaxWidth().padding(top = 10.dp)
                        )
                    }
                    is RenderBlock.Paragraph -> {
                        Text(
                            text = block.text,
                            fontSize = fontSize.sp,
                            lineHeight = (fontSize * lineSpacing).sp,
                            fontFamily = fontFamily,
                            color = canvasText,
                            textAlign = textAlign,
                            modifier = Modifier.fillMaxWidth()
                        )
                    }
                    is RenderBlock.Quote -> {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .border(
                                    width = if (isUrdu) 0.dp else 3.dp,
                                    color = accentColor.copy(alpha = 0.6f),
                                    shape = RoundedCornerShape(4.dp)
                                )
                                .background(accentColor.copy(alpha = 0.05f))
                                .padding(12.dp)
                        ) {
                            Text(
                                text = block.text,
                                fontSize = (fontSize * 1.05f).sp,
                                lineHeight = (fontSize * lineSpacing * 1.1f).sp,
                                fontFamily = fontFamily,
                                fontWeight = if (isUrdu) FontWeight.SemiBold else FontWeight.Normal,
                                color = canvasText,
                                textAlign = textAlign,
                                modifier = Modifier.fillMaxWidth()
                            )
                        }
                    }
                    is RenderBlock.Code -> {
                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = canvasBorder.copy(alpha = 0.3f),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text(
                                text = block.code,
                                fontFamily = JetBrainsMono,
                                fontSize = 12.sp,
                                color = canvasText,
                                modifier = Modifier.padding(10.dp)
                            )
                        }
                    }
                    is RenderBlock.ListBlock -> {
                        Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                            block.items.forEachIndexed { i, item ->
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = if (isUrdu) Arrangement.End else Arrangement.Start
                                ) {
                                    val bullet = if (block.isOrdered) "${i + 1}. " else "• "
                                    Text(
                                        text = if (isUrdu) "$item $bullet" else "$bullet$item",
                                        fontSize = fontSize.sp,
                                        fontFamily = fontFamily,
                                        color = canvasText
                                    )
                                }
                            }
                        }
                    }
                    is RenderBlock.Table -> {
                        Column(
                            modifier = Modifier.fillMaxWidth().border(1.dp, canvasBorder, RoundedCornerShape(8.dp))
                        ) {
                            if (block.headers.isNotEmpty()) {
                                Row(
                                    modifier = Modifier.fillMaxWidth().background(accentColor.copy(alpha = 0.1f)).padding(8.dp)
                                ) {
                                    block.headers.forEach { h ->
                                        Text(text = h, fontWeight = FontWeight.Bold, fontSize = 12.sp, color = canvasText, modifier = Modifier.weight(1f))
                                    }
                                }
                            }
                            block.rows.forEach { r ->
                                HorizontalDivider(color = canvasBorder.copy(alpha = 0.5f))
                                Row(modifier = Modifier.fillMaxWidth().padding(8.dp)) {
                                    r.forEach { cell ->
                                        Text(text = cell, fontSize = 12.sp, color = canvasText, modifier = Modifier.weight(1f))
                                    }
                                }
                            }
                        }
                    }
                    else -> {}
                }
            }
        }
    }
}

@Composable
private fun EpiphanyToc(
    toc: List<TocItem>,
    accentColor: Color,
    onSelect: (TocItem) -> Unit
) {
    if (toc.isEmpty()) {
        Box(modifier = Modifier.fillMaxSize().padding(20.dp), contentAlignment = Alignment.Center) {
            Text("No headings found.", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        return
    }

    LazyColumn(modifier = Modifier.fillMaxSize().padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
        items(toc) { item ->
            val indent = ((item.level - 1) * 12).dp
            Surface(
                modifier = Modifier.fillMaxWidth().padding(start = indent).clip(RoundedCornerShape(8.dp)).clickable { onSelect(item) },
                color = Color.Transparent
            ) {
                Text(
                    text = item.title,
                    fontSize = 13.sp,
                    fontWeight = if (item.level == 1) FontWeight.Bold else FontWeight.Normal,
                    color = if (item.level == 1) accentColor else MaterialTheme.colorScheme.onSurface,
                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 6.dp)
                )
            }
        }
    }
}

@Composable
private fun EpiphanyTypographySheet(
    settings: ReaderSettings,
    accentColor: Color,
    onSettingsChange: (ReaderSettings) -> Unit,
    onClose: () -> Unit
) {
    val onSurfaceColor = MaterialTheme.colorScheme.onSurface

    Column(modifier = Modifier.fillMaxWidth().padding(18.dp)) {
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            Text("MrMWSK EPIPHANY Typography", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
            IconButton(onClick = onClose) { Icon(Icons.Default.Close, contentDescription = "Close") }
        }

        Spacer(modifier = Modifier.height(10.dp))
        Text(text = "Reading Theme", fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            ReadingTheme.values().forEach { t ->
                FilterChip(
                    selected = settings.theme == t,
                    onClick = { onSettingsChange(settings.copy(theme = t)) },
                    label = { Text(t.name.lowercase().replaceFirstChar { it.uppercase() }) }
                )
            }
        }

        Spacer(modifier = Modifier.height(8.dp))
        Text(text = "Accent Color", fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            ReaderAccent.values().forEach { acc ->
                val isSelected = settings.accent == acc
                Box(
                    modifier = Modifier
                        .size(32.dp)
                        .clip(CircleShape)
                        .background(Color(acc.hexColor))
                        .border(
                            width = if (isSelected) 3.dp else 1.dp,
                            color = if (isSelected) onSurfaceColor else Color.Transparent,
                            shape = CircleShape
                        )
                        .clickable { onSettingsChange(settings.copy(accent = acc)) }
                )
            }
        }

        Spacer(modifier = Modifier.height(14.dp))
        HorizontalDivider()
        Spacer(modifier = Modifier.height(10.dp))

        // Urdu & Roman Urdu Group
        Text("Urdu & Roman Urdu Typography", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = accentColor)
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            UrduFontFamily.values().forEach { f ->
                FilterChip(
                    selected = settings.urduFont == f,
                    onClick = { onSettingsChange(settings.copy(urduFont = f)) },
                    label = { Text(f.name.lowercase().replaceFirstChar { it.uppercase() }) }
                )
            }
        }

        Text("Size: ${settings.urduFontSizeSp.toInt()}sp", fontSize = 11.sp)
        Slider(
            value = settings.urduFontSizeSp,
            onValueChange = { onSettingsChange(settings.copy(urduFontSizeSp = it)) },
            valueRange = 14f..32f
        )

        Text("Line Spacing: ${String.format("%.1f", settings.urduLineSpacing)}", fontSize = 11.sp)
        Slider(
            value = settings.urduLineSpacing,
            onValueChange = { onSettingsChange(settings.copy(urduLineSpacing = it)) },
            valueRange = 1.2f..2.8f
        )

        Spacer(modifier = Modifier.height(10.dp))
        HorizontalDivider()
        Spacer(modifier = Modifier.height(10.dp))

        // English Group
        Text("English Typography", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = accentColor)
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            EnglishFontFamily.values().forEach { f ->
                FilterChip(
                    selected = settings.englishFont == f,
                    onClick = { onSettingsChange(settings.copy(englishFont = f)) },
                    label = { Text(f.name.lowercase().replaceFirstChar { it.uppercase() }) }
                )
            }
        }

        Text("Size: ${settings.englishFontSizeSp.toInt()}sp", fontSize = 11.sp)
        Slider(
            value = settings.englishFontSizeSp,
            onValueChange = { onSettingsChange(settings.copy(englishFontSizeSp = it)) },
            valueRange = 14f..32f
        )

        Text("Line Spacing: ${String.format("%.1f", settings.englishLineSpacing)}", fontSize = 11.sp)
        Slider(
            value = settings.englishLineSpacing,
            onValueChange = { onSettingsChange(settings.copy(englishLineSpacing = it)) },
            valueRange = 1.2f..2.8f
        )
    }
}

private data class Quintuple<A, B, C, D, E>(val first: A, val second: B, val third: C, val fourth: D, val fifth: E)
