package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarDuration
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.ui.AppDestination
import com.example.ui.MainViewModel
import com.example.ui.about.AboutScreen
import com.example.ui.components.AppBottomBar
import com.example.ui.components.AppNavigationRail
import com.example.ui.flux.FluxScreen
import com.example.ui.library.LibraryScreen
import com.example.ui.theme.MyApplicationTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MyApplicationTheme {
                MainApp()
            }
        }
    }
}

@Composable
fun MainApp(
    viewModel: MainViewModel = viewModel()
) {
    val currentDestination by viewModel.currentDestination.collectAsState()
    val feedback by viewModel.uiFeedback.collectAsState()
    val snackbarHostState = remember { SnackbarHostState() }

    // Display Snackbars on feedback events
    LaunchedEffect(feedback) {
        feedback?.let { fb ->
            snackbarHostState.showSnackbar(
                message = fb.message,
                duration = SnackbarDuration.Short
            )
            viewModel.clearFeedback()
        }
    }

    // Handle back button logically
    BackHandler(enabled = currentDestination != AppDestination.FLUX_AUDIT) {
        viewModel.navigateTo(AppDestination.FLUX_AUDIT)
    }

    BoxWithConstraints(
        modifier = Modifier
            .fillMaxSize()
            .windowInsetsPadding(WindowInsets.safeDrawing)
    ) {
        val isWideScreen = maxWidth >= 760.dp

        if (isWideScreen) {
            // Tablet & Wide Desktop: Navigation Rail on Left + Content Pane
            Row(modifier = Modifier.fillMaxSize()) {
                AppNavigationRail(
                    currentDestination = currentDestination,
                    onNavigate = { viewModel.navigateTo(it) }
                )

                Box(modifier = Modifier.weight(1f).fillMaxSize()) {
                    AppContent(currentDestination, viewModel)
                    SnackbarHost(hostState = snackbarHostState)
                }
            }
        } else {
            // Phone: Standard Scaffold with Bottom Bar
            Scaffold(
                modifier = Modifier.fillMaxSize(),
                bottomBar = {
                    AppBottomBar(
                        currentDestination = currentDestination,
                        onNavigate = { viewModel.navigateTo(it) }
                    )
                },
                snackbarHost = { SnackbarHost(snackbarHostState) }
            ) { innerPadding ->
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(innerPadding)
                ) {
                    AppContent(currentDestination, viewModel)
                }
            }
        }
    }
}

@Composable
private fun AppContent(
    destination: AppDestination,
    viewModel: MainViewModel
) {
    AnimatedContent(
        targetState = destination,
        transitionSpec = { fadeIn() togetherWith fadeOut() },
        label = "screen_transition"
    ) { dest ->
        when (dest) {
            AppDestination.FLUX_AUDIT -> FluxScreen(viewModel = viewModel)
            AppDestination.LIBRARY -> LibraryScreen(viewModel = viewModel)
            AppDestination.EXPORT_HELP -> AboutScreen()
        }
    }
}
