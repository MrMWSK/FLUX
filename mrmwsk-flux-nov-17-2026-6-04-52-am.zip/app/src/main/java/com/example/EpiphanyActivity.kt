package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.material3.Surface
import androidx.compose.ui.Modifier
import com.example.ui.epiphany.EpiphanyScreen
import com.example.ui.theme.MyApplicationTheme

/**
 * MrMWSK EPIPHANY
 * Standalone offline reader studio activity for multilingual literature,
 * Urdu Nastaliq/Arabic typography, and distraction-free focus reading.
 */
class EpiphanyActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        val initialHtml = intent?.getStringExtra("EXTRA_HTML")
        val initialTitle = intent?.getStringExtra("EXTRA_TITLE")

        setContent {
            MyApplicationTheme {
                Surface(
                    modifier = Modifier
                        .fillMaxSize()
                        .windowInsetsPadding(WindowInsets.safeDrawing)
                ) {
                    EpiphanyScreen(
                        initialHtml = initialHtml,
                        initialTitle = initialTitle
                    )
                }
            }
        }
    }
}
