package com.example.data.model

object SampleDocuments {

    val FLUX_TEST_SAMPLE = """
<!doctype html>
<html>
<head>
  <title>Developer Portfolio & Articles</title>
  <!-- Note: viewport, charset, and lang intentionally omitted to demonstrate FLUX auditing -->
</head>
<body>
  <header>
    <h1>Modern Web Architecture</h1>
  </header>
  <main>
    <p>Welcome to our engineering handbook on building resilient, accessible user experiences.</p>
    
    <!-- Link with placeholder target -->
    <a href="#">Jump to top (placeholder link)</a>
    <br>
    <a href="#nonexistent-anchor">Read architectural benchmarks</a>

    <!-- Heading level skipped: jumps from H1 to H3 -->
    <h3>Performance &amp; Core Web Vitals</h3>
    <p>Ensuring fast first-contentful-paint across low-bandwidth cellular environments.</p>

    <!-- Images: one without alt, one with empty alt -->
    <img src="https://images.unsplash.com/photo-1461749280684-dccba630e2f6?w=600">
    <img src="https://images.unsplash.com/photo-1555066931-4365d14bab8c?w=600" alt="">

    <!-- Form without accessible label -->
    <div>
      <input type="text" placeholder="Enter newsletter email">
      <button type="button">Subscribe</button>
    </div>

    <!-- Duplicate ID -->
    <div id="content-block">Primary section text</div>
    <div id="content-block">Secondary section text</div>

    <!-- Table without th headers -->
    <table>
      <tr><td>Metric</td><td>Target</td></tr>
      <tr><td>LCP</td><td>&lt; 2.5s</td></tr>
      <tr><td>CLS</td><td>&lt; 0.1</td></tr>
    </table>
  </main>
</body>
</html>
""".trimIndent()

    val OPENLEAF_MULTILINGUAL_SAMPLE = """
<!doctype html>
<html lang="ur">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>OpenLeaf Diwan — Classical Urdu Poetry &amp; Translations</title>
  <meta name="description" content="A multilingual reading anthology of classical Urdu ghazals with Roman transliterations and English translations.">
</head>
<body>
  <header>
    <h1>دیوانِ غالب و اقبال — Anthology of Classical Verse</h1>
  </header>
  
  <main>
    <h2 id="ghalib-ghazal">مرزا اسد اللہ خان غالب — Mirza Ghalib</h2>
    
    <div class="urdu" lang="ur">
      <blockquote style="font-size: 20px; line-height: 2;">
        ہزاروں خواہشیں ایسی کہ ہر خواہش پہ دم نکلے<br>
        بہت نکلے مرے ارمان لیکن پھر بھی کم نکلے<br><br>
        نکلنا خلد سے آدم کا سنتے آئے ہیں لیکن<br>
        بہت بے آبرو ہو کر ترے کوچے سے ہم نکلے
      </blockquote>
    </div>

    <div class="roman" lang="ur-Latn">
      <h3>Roman Urdu Transliteration</h3>
      <p>
        Hazaron khwahishen aisi ke har khwahish pe dam nikle<br>
        Bohat nikle mere armaan lekin phir bhi kam nikle<br><br>
        Nikalna khuld se aadam ka sunte aaye hain lekin<br>
        Bohat be-aabroo ho kar tere kooche se hum nikle
      </p>
    </div>

    <div class="english" lang="en">
      <h3>English Poetic Translation</h3>
      <p>
        Thousands of desires, each so profound that every yearning takes a breath away;<br>
        So many of my longings found release, yet still they felt too few.<br><br>
        We have always heard of Adam’s banishment from paradise,<br>
        Yet far more disgraced did I depart from the lane of your beloved presence.
      </p>
    </div>

    <h2 id="iqbal-shikwa">علامہ محمد اقبال — Allama Iqbal (Bang-e-Dra)</h2>

    <div class="urdu" lang="ur">
      <blockquote style="font-size: 20px; line-height: 2;">
        خودی کو کر بلند اتنا کہ ہر تقدیر سے پہلے<br>
        خدا بندے سے خود پوچھے بتا تیری رضا کیا ہے
      </blockquote>
    </div>

    <div class="roman" lang="ur-Latn">
      <h3>Roman Urdu Transliteration</h3>
      <p>
        Khudi ko kar buland itna ke har taqdeer se pehle<br>
        Khuda bande se khud pooche bata teri raza kya hai
      </p>
    </div>

    <div class="english" lang="en">
      <h3>English Poetic Translation</h3>
      <p>
        Elevate your selfhood to such exalted heights that before determining any destiny,<br>
        God Himself asks the seeker: 'Speak, what is your sacred wish?'
      </p>
    </div>

    <h2 id="glossary">ادبی فرہنگ — Literary Glossary</h2>
    <table>
      <thead>
        <tr>
          <th>لفظ / Word</th>
          <th>Transliteration</th>
          <th>Meaning in English</th>
        </tr>
      </thead>
      <tbody>
        <tr>
          <td class="urdu">خودی</td>
          <td>Khudi</td>
          <td>Selfhood, spiritual consciousness, self-realization</td>
        </tr>
        <tr>
          <td class="urdu">خلد</td>
          <td>Khuld</td>
          <td>Eternity, Paradise, the celestial garden</td>
        </tr>
        <tr>
          <td class="urdu">ارمان</td>
          <td>Armaan</td>
          <td>Deep yearning, aspirational longing</td>
        </tr>
      </tbody>
    </table>
  </main>
</body>
</html>
""".trimIndent()

    val CLEAN_COMPLIANT_ARTICLE = """
<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Principles of Resilient Offline-First Design</title>
  <meta name="description" content="A guide to architecting mobile applications that function seamlessly without constant connectivity.">
</head>
<body>
  <header>
    <h1>Principles of Resilient Offline-First Design</h1>
  </header>
  <main>
    <p>Designing software for erratic network conditions requires treating local state as the source of truth.</p>
    
    <h2 id="local-persistence">1. Local-First Persistence</h2>
    <p>Every mutation is recorded to local storage immediately, ensuring zero perceived latency for user interactions.</p>
    
    <h2 id="accessible-markup">2. Accessible Semantic Markup</h2>
    <p>Structuring documents with valid headings, landmarks, and high-contrast color schemes enables accessibility for all users.</p>
    
    <img src="https://images.unsplash.com/photo-1517694712202-14dd9538aa97?w=600" alt="Laptop computer displaying clean code next to a notebook">

    <h2 id="summary">3. Conclusion</h2>
    <p>By prioritizing offline capability and accessibility standards, applications deliver dependable performance anywhere.</p>
    
    <a href="#local-persistence">Return to section on Local-First Persistence</a>
  </main>
</body>
</html>
""".trimIndent()
}
