package com.example.data.repository

import com.example.data.local.DocumentDao
import com.example.data.model.SavedDocument
import kotlinx.coroutines.flow.Flow

class DocumentRepository(private val documentDao: DocumentDao) {
    val allDocuments: Flow<List<SavedDocument>> = documentDao.getAllDocuments()

    fun search(query: String): Flow<List<SavedDocument>> = documentDao.searchDocuments(query)

    fun getDocument(id: Long): Flow<SavedDocument?> = documentDao.getDocumentById(id)

    suspend fun insert(document: SavedDocument): Long = documentDao.insertDocument(document)

    suspend fun update(document: SavedDocument) = documentDao.updateDocument(document)

    suspend fun delete(document: SavedDocument) = documentDao.deleteDocument(document)

    suspend fun deleteById(id: Long) = documentDao.deleteDocumentById(id)

    suspend fun setFavorite(id: Long, isFavorite: Boolean) = documentDao.setFavorite(id, isFavorite)

    suspend fun count(): Int = documentDao.getCount()
}
