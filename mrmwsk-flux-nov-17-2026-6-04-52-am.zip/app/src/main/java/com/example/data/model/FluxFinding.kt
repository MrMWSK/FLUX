package com.example.data.model

enum class FindingSeverity {
    ERROR,
    WARNING,
    PASS
}

enum class AuditCategory {
    OVERVIEW,
    ACCESSIBILITY,
    SEO,
    PERFORMANCE,
    QUALITY
}

data class FluxFinding(
    val id: String,
    val severity: FindingSeverity,
    val category: AuditCategory,
    val title: String,
    val detail: String,
    val suggestedFix: String = "",
    val whyItMatters: String = "",
    val howToResolve: List<String> = emptyList(),
    val solutionSnippet: String = "",
    val canAutoFix: Boolean = false
)

data class CategoryScore(
    val category: AuditCategory,
    val name: String,
    val score: Int,
    val errorCount: Int,
    val warningCount: Int,
    val passCount: Int
)

data class FluxReport(
    val score: Int,
    val errorsCount: Int,
    val warningsCount: Int,
    val passesCount: Int,
    val applicableCount: Int,
    val sourceSizeBytes: Int,
    val findings: List<FluxFinding>,
    val categoryScores: List<CategoryScore>
)
