package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "documents")
data class SavedDocument(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val title: String,
    val fileName: String,
    val rawHtml: String,
    val cleanedHtml: String,
    val fluxScore: Int = 100,
    val errorsCount: Int = 0,
    val warningsCount: Int = 0,
    val urduCount: Int = 0,
    val romanCount: Int = 0,
    val englishCount: Int = 0,
    val wordCount: Int = 0,
    val createdAt: Long = System.currentTimeMillis(),
    val isFavorite: Boolean = false
)
