package com.example.data.model

enum class ReadingTheme {
    LIGHT,
    SEPIA,
    DARK
}

enum class ReaderAccent(val title: String, val hexColor: Long) {
    MRMWSK_GREEN("MrMWSK Green", 0xFF315E50),
    ROYAL_BLUE("Blue", 0xFF1F329C),
    BERRY("Berry", 0xFF8A5B74),
    AMBER("Amber", 0xFFA36B32)
}

typealias ReadingAccent = ReaderAccent

enum class UrduFontFamily {
    NASTALIQ,
    ARABIC,
    SANS
}

enum class EnglishFontFamily {
    SYSTEM,
    SERIF,
    MONO
}

enum class LanguageFilter {
    ALL,
    URDU,
    ROMAN_URDU,
    ENGLISH
}

data class TocItem(
    val id: String,
    val title: String,
    val level: Int,
    val position: Int
)

data class ReaderSettings(
    val theme: ReadingTheme = ReadingTheme.LIGHT,
    val accent: ReadingAccent = ReadingAccent.MRMWSK_GREEN,
    val activeFilter: LanguageFilter = LanguageFilter.ALL,
    val isFocusMode: Boolean = false,
    
    // Independent Urdu & Roman Urdu typography
    val urduFont: UrduFontFamily = UrduFontFamily.NASTALIQ,
    val urduFontSizeSp: Float = 20f,
    val urduLineSpacing: Float = 1.9f,

    // Independent English typography
    val englishFont: EnglishFontFamily = EnglishFontFamily.SERIF,
    val englishFontSizeSp: Float = 18f,
    val englishLineSpacing: Float = 1.6f
)

data class DocumentStats(
    val wordCount: Int = 0,
    val readingTimeMinutes: Int = 0,
    val urduSectionsCount: Int = 0,
    val romanUrduSectionsCount: Int = 0,
    val englishSectionsCount: Int = 0,
    val headingsCount: Int = 0
)
