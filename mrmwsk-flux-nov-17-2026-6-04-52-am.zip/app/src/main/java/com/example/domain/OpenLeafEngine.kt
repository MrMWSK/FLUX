package com.example.domain

import com.example.data.model.DocumentStats
import com.example.data.model.LanguageFilter
import com.example.data.model.TocItem
import org.jsoup.Jsoup
import org.jsoup.nodes.Document
import org.jsoup.nodes.Element
import org.jsoup.nodes.TextNode

sealed class RenderBlock(val id: String, val detectedLang: String, val isRtl: Boolean) {
    data class Heading(
        val blockId: String,
        val level: Int,
        val text: String,
        val lang: String,
        val rtl: Boolean
    ) : RenderBlock(blockId, lang, rtl)

    data class Paragraph(
        val blockId: String,
        val text: String,
        val lang: String,
        val rtl: Boolean
    ) : RenderBlock(blockId, lang, rtl)

    data class Quote(
        val blockId: String,
        val text: String,
        val lang: String,
        val rtl: Boolean
    ) : RenderBlock(blockId, lang, rtl)

    data class Code(
        val blockId: String,
        val code: String
    ) : RenderBlock(blockId, "english", false)

    data class ImageBlock(
        val blockId: String,
        val src: String,
        val alt: String
    ) : RenderBlock(blockId, "", false)

    data class ListBlock(
        val blockId: String,
        val items: List<String>,
        val isOrdered: Boolean,
        val lang: String,
        val rtl: Boolean
    ) : RenderBlock(blockId, lang, rtl)

    data class Table(
        val blockId: String,
        val headers: List<String>,
        val rows: List<List<String>>
    ) : RenderBlock(blockId, "", false)
}

data class OpenLeafParseResult(
    val title: String,
    val cleanedHtml: String,
    val blocks: List<RenderBlock>,
    val toc: List<TocItem>,
    val stats: DocumentStats
)

object OpenLeafEngine {

    // Regex patterns for language matching
    private val URDU_ATTR_REGEX = Regex("urdu|nastaliq|arabic|\\bur\\b", RegexOption.IGNORE_CASE)
    private val ROMAN_ATTR_REGEX = Regex("roman|translit|roman-urdu", RegexOption.IGNORE_CASE)
    private val ENGLISH_ATTR_REGEX = Regex("english|translation|\\ben\\b", RegexOption.IGNORE_CASE)
    private val URDU_UNICODE_REGEX = Regex("[\\u0600-\\u06FF\\u0750-\\u077F\\uFB50-\\uFDFF\\uFE70-\\uFEFF]")

    fun sanitizeDocument(doc: Document): Document {
        // Remove unsafe/active tags
        doc.select("script, iframe, object, embed, form, base, meta[http-equiv], link[rel=import]").remove()

        // Remove on* event handlers and javascript: URLs
        doc.allElements.forEach { element ->
            val attrsToRemove = element.attributes().filter { attr ->
                attr.key.startsWith("on", ignoreCase = true) ||
                        ((attr.key.equals("href", ignoreCase = true) || attr.key.equals("src", ignoreCase = true)) &&
                                attr.value.trim().startsWith("javascript:", ignoreCase = true))
            }.map { it.key }

            attrsToRemove.forEach { key ->
                element.removeAttr(key)
            }
        }
        return doc
    }

    fun detectLanguage(element: Element): String {
        val attrString = (element.attr("lang") + " " + element.className() + " " + element.id()).lowercase()
        if (URDU_ATTR_REGEX.containsMatchIn(attrString)) return "urdu"
        if (ROMAN_ATTR_REGEX.containsMatchIn(attrString)) return "roman"
        if (ENGLISH_ATTR_REGEX.containsMatchIn(attrString)) return "english"

        // Check text content heuristic
        val text = element.text()
        if (URDU_UNICODE_REGEX.containsMatchIn(text)) return "urdu"

        // Heuristic for Roman Urdu markers
        val lowerText = text.lowercase()
        val romanUrduKeywords = listOf("hai", "hain", "nahin", "aur", "mein", "mera", "meri", "hum", "tum", "kya", "kyun", "shairi", "dil", "muhabbat")
        val words = lowerText.split("\\s+".toRegex())
        val matchCount = words.count { it in romanUrduKeywords }
        if (matchCount >= 2) return "roman"

        return if (text.isNotBlank()) "english" else ""
    }

    fun parse(rawHtml: String): OpenLeafParseResult {
        val trimmed = rawHtml.trim()
        if (trimmed.isEmpty()) {
            return OpenLeafParseResult(
                title = "Empty Document",
                cleanedHtml = "",
                blocks = emptyList(),
                toc = emptyList(),
                stats = DocumentStats()
            )
        }

        val parsedDoc = Jsoup.parse(trimmed)
        val cleanDoc = sanitizeDocument(parsedDoc)
        val title = cleanDoc.title().ifBlank {
            cleanDoc.selectFirst("h1")?.text()?.take(50) ?: "Untitled Document"
        }

        val blocks = mutableListOf<RenderBlock>()
        val tocList = mutableListOf<TocItem>()
        var blockIdCounter = 0

        var urduCount = 0
        var romanCount = 0
        var englishCount = 0
        var headingsCount = 0

        val body = cleanDoc.body() ?: cleanDoc

        // Walk through top-level elements inside body or main
        val mainElement = body.selectFirst("main") ?: body
        val childElements = if (mainElement.children().isEmpty()) listOf(mainElement) else mainElement.children()

        for (child in childElements) {
            processElement(child, blocks, tocList, { blockIdCounter++ })
        }

        // Calculate language counts and total words from blocks
        var totalWords = 0
        blocks.forEach { block ->
            when (block) {
                is RenderBlock.Heading -> {
                    headingsCount++
                    totalWords += countWords(block.text)
                    when (block.detectedLang) {
                        "urdu" -> urduCount++
                        "roman" -> romanCount++
                        "english" -> englishCount++
                    }
                }
                is RenderBlock.Paragraph -> {
                    totalWords += countWords(block.text)
                    when (block.detectedLang) {
                        "urdu" -> urduCount++
                        "roman" -> romanCount++
                        "english" -> englishCount++
                    }
                }
                is RenderBlock.Quote -> {
                    totalWords += countWords(block.text)
                    when (block.detectedLang) {
                        "urdu" -> urduCount++
                        "roman" -> romanCount++
                        "english" -> englishCount++
                    }
                }
                is RenderBlock.ListBlock -> {
                    block.items.forEach { totalWords += countWords(it) }
                    when (block.detectedLang) {
                        "urdu" -> urduCount++
                        "roman" -> romanCount++
                        "english" -> englishCount++
                    }
                }
                else -> {}
            }
        }

        val readingMinutes = maxOf(1, (totalWords / 200.0).toInt())

        val stats = DocumentStats(
            wordCount = totalWords,
            readingTimeMinutes = readingMinutes,
            urduSectionsCount = urduCount,
            romanUrduSectionsCount = romanCount,
            englishSectionsCount = englishCount,
            headingsCount = headingsCount
        )

        return OpenLeafParseResult(
            title = title,
            cleanedHtml = "<!doctype html>\n" + cleanDoc.outerHtml(),
            blocks = blocks,
            toc = tocList,
            stats = stats
        )
    }

    private fun processElement(
        element: Element,
        blocks: MutableList<RenderBlock>,
        tocList: MutableList<TocItem>,
        nextId: () -> Int
    ) {
        val tag = element.tagName().lowercase()
        val text = element.text().trim()
        val lang = detectLanguage(element)
        val isRtl = lang == "urdu" || URDU_UNICODE_REGEX.containsMatchIn(text)

        when {
            tag in listOf("h1", "h2", "h3", "h4", "h5", "h6") -> {
                val level = tag.removePrefix("h").toIntOrNull() ?: 1
                val headingId = element.id().ifBlank { "heading_${tocList.size + 1}" }
                if (text.isNotEmpty()) {
                    blocks.add(
                        RenderBlock.Heading(
                            blockId = headingId,
                            level = level,
                            text = text,
                            lang = lang,
                            rtl = isRtl
                        )
                    )
                    tocList.add(
                        TocItem(
                            id = headingId,
                            title = text,
                            level = level,
                            position = blocks.size - 1
                        )
                    )
                }
            }
            tag == "p" -> {
                if (text.isNotEmpty()) {
                    blocks.add(
                        RenderBlock.Paragraph(
                            blockId = "p_${nextId()}",
                            text = text,
                            lang = lang,
                            rtl = isRtl
                        )
                    )
                }
            }
            tag == "blockquote" -> {
                if (text.isNotEmpty()) {
                    blocks.add(
                        RenderBlock.Quote(
                            blockId = "q_${nextId()}",
                            text = text,
                            lang = lang,
                            rtl = isRtl
                        )
                    )
                }
            }
            tag == "pre" || tag == "code" -> {
                if (text.isNotEmpty()) {
                    blocks.add(
                        RenderBlock.Code(
                            blockId = "code_${nextId()}",
                            code = text
                        )
                    )
                }
            }
            tag == "img" -> {
                val src = element.attr("src")
                val alt = element.attr("alt")
                blocks.add(
                    RenderBlock.ImageBlock(
                        blockId = "img_${nextId()}",
                        src = src,
                        alt = alt
                    )
                )
            }
            tag in listOf("ul", "ol") -> {
                val items = element.select("li").map { it.text().trim() }.filter { it.isNotEmpty() }
                if (items.isNotEmpty()) {
                    blocks.add(
                        RenderBlock.ListBlock(
                            blockId = "list_${nextId()}",
                            items = items,
                            isOrdered = tag == "ol",
                            lang = lang,
                            rtl = isRtl
                        )
                    )
                }
            }
            tag == "table" -> {
                val headers = element.select("th").map { it.text().trim() }
                val rows = element.select("tr").mapNotNull { tr ->
                    val cells = tr.select("td").map { it.text().trim() }
                    if (cells.isNotEmpty()) cells else null
                }
                if (headers.isNotEmpty() || rows.isNotEmpty()) {
                    blocks.add(
                        RenderBlock.Table(
                            blockId = "table_${nextId()}",
                            headers = headers,
                            rows = rows
                        )
                    )
                }
            }
            tag in listOf("div", "section", "article", "main", "header", "footer") -> {
                // If it contains direct paragraph/children, recurse
                val children = element.children()
                if (children.isNotEmpty()) {
                    for (child in children) {
                        processElement(child, blocks, tocList, nextId)
                    }
                } else if (text.isNotEmpty()) {
                    blocks.add(
                        RenderBlock.Paragraph(
                            blockId = "p_${nextId()}",
                            text = text,
                            lang = lang,
                            rtl = isRtl
                        )
                    )
                }
            }
            text.isNotEmpty() -> {
                blocks.add(
                    RenderBlock.Paragraph(
                        blockId = "p_${nextId()}",
                        text = text,
                        lang = lang,
                        rtl = isRtl
                    )
                )
            }
        }
    }

    private fun countWords(text: String): Int {
        val trimmed = text.trim()
        if (trimmed.isEmpty()) return 0
        return trimmed.split("\\s+".toRegex()).size
    }

    fun filterBlocks(blocks: List<RenderBlock>, filter: LanguageFilter): List<RenderBlock> {
        if (filter == LanguageFilter.ALL) return blocks
        val filterKey = when (filter) {
            LanguageFilter.URDU -> "urdu"
            LanguageFilter.ROMAN_URDU -> "roman"
            LanguageFilter.ENGLISH -> "english"
            LanguageFilter.ALL -> ""
        }
        return blocks.filter { block ->
            // Keep neutral elements like Code, Table, or elements matching the language filter
            when (block) {
                is RenderBlock.Code, is RenderBlock.Table -> true
                else -> block.detectedLang.isEmpty() || block.detectedLang == filterKey
            }
        }
    }
}
