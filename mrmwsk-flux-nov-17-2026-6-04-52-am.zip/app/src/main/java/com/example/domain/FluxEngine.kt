package com.example.domain

import com.example.data.model.AuditCategory
import com.example.data.model.CategoryScore
import com.example.data.model.FindingSeverity
import com.example.data.model.FluxFinding
import com.example.data.model.FluxReport
import org.jsoup.Jsoup
import org.jsoup.nodes.Document
import org.jsoup.nodes.Element
import java.net.URLDecoder

object FluxEngine {

    fun analyzeHtml(html: String): FluxReport {
        val trimmed = html.trim()
        val sourceSizeBytes = html.toByteArray(Charsets.UTF_8).size
        if (trimmed.isEmpty()) {
            return FluxReport(
                score = 100,
                errorsCount = 0,
                warningsCount = 0,
                passesCount = 0,
                applicableCount = 0,
                sourceSizeBytes = 0,
                findings = emptyList(),
                categoryScores = emptyList()
            )
        }

        val doc: Document = Jsoup.parse(trimmed)
        val findings = mutableListOf<FluxFinding>()
        var counter = 1

        fun add(
            severity: FindingSeverity,
            category: AuditCategory,
            title: String,
            detail: String,
            suggestedFix: String = "",
            whyItMatters: String = "",
            howToResolve: List<String> = emptyList(),
            solutionSnippet: String = "",
            canAutoFix: Boolean = false
        ) {
            findings.add(
                FluxFinding(
                    id = "finding_${counter++}",
                    severity = severity,
                    category = category,
                    title = title,
                    detail = detail,
                    suggestedFix = suggestedFix,
                    whyItMatters = whyItMatters,
                    howToResolve = howToResolve,
                    solutionSnippet = solutionSnippet,
                    canAutoFix = canAutoFix
                )
            )
        }

        fun hasAccessibleName(el: Element): Boolean {
            val ariaLabel = el.attr("aria-label").trim()
            if (ariaLabel.isNotEmpty()) return true

            val labelledBy = el.attr("aria-labelledby").trim()
            if (labelledBy.isNotEmpty()) {
                val ids = labelledBy.split("\\s+".toRegex())
                val allValid = ids.all { id ->
                    val target = doc.getElementById(id)
                    target != null && target.text().trim().isNotEmpty()
                }
                if (allValid) return true
            }

            val tagName = el.tagName().lowercase()
            if (tagName == "input") {
                val type = el.attr("type").lowercase()
                if (type in listOf("button", "submit", "reset", "image")) {
                    return elementHasText(el.attr("value"))
                }
            }

            if (tagName == "img") {
                return el.hasAttr("alt") && el.attr("alt").trim().isNotEmpty()
            }

            if (el.text().trim().isNotEmpty()) return true
            return el.selectFirst("img[alt]:not([alt=''])") != null
        }

        // ==========================================
        // 1. Accessibility Checks (WCAG 2.1 AA)
        // ==========================================
        val htmlElement = doc.selectFirst("html")
        val lang = htmlElement?.attr("lang")?.trim() ?: ""
        if (lang.isEmpty()) {
            add(
                severity = FindingSeverity.ERROR,
                category = AuditCategory.ACCESSIBILITY,
                title = "Missing page language",
                detail = "The <html> element has no language declaration.",
                suggestedFix = "Add a valid lang attribute to <html>.",
                whyItMatters = "Screen readers require the document language to select correct speech synthesis rules and pronunciation dictionaries.",
                howToResolve = listOf(
                    "Locate the opening <html> tag at the top of your document.",
                    "Add the attribute lang=\"en\" for English, lang=\"ur\" for Urdu, or another BCP-47 language tag.",
                    "Example: <html lang=\"en\">"
                ),
                solutionSnippet = "<html lang=\"en\">",
                canAutoFix = true
            )
        } else {
            add(
                severity = FindingSeverity.PASS,
                category = AuditCategory.ACCESSIBILITY,
                title = "Page language declared",
                detail = "The document declares language \"$lang\"."
            )
        }

        // Image Alternative Text
        val images = doc.select("img")
        var imgMissingAlt = 0
        var imgEmptyAlt = 0
        images.forEachIndexed { i, img ->
            val src = img.attr("src").take(32)
            if (!img.hasAttr("alt")) {
                imgMissingAlt++
                add(
                    severity = FindingSeverity.ERROR,
                    category = AuditCategory.ACCESSIBILITY,
                    title = "Image missing alt text",
                    detail = "Image ${i + 1} ($src) has no alt attribute.",
                    suggestedFix = "Add concise descriptive text, or alt=\"\" if decorative.",
                    whyItMatters = "Visually impaired users rely on alt text to understand images. Without it, screen readers read the confusing image URL or file path.",
                    howToResolve = listOf(
                        "Determine if the image conveys information or is purely decorative.",
                        "If informative: write a short, accurate description (e.g. alt=\"Architecture diagram\").",
                        "If decorative: set alt=\"\" so screen readers skip it without distraction."
                    ),
                    solutionSnippet = "alt=\"Descriptive text for this image\"",
                    canAutoFix = true
                )
            } else if (img.attr("alt").trim().isEmpty()) {
                imgEmptyAlt++
                add(
                    severity = FindingSeverity.WARNING,
                    category = AuditCategory.ACCESSIBILITY,
                    title = "Empty image alternative",
                    detail = "Image ${i + 1} has alt=\"\"; confirm it is purely decorative.",
                    suggestedFix = "Provide descriptive alt text if the image communicates essential meaning.",
                    whyItMatters = "An empty alt attribute marks an image as invisible to assistive technology. Ensure it does not contain important charts, icons, or badges.",
                    howToResolve = listOf(
                        "Check if this image communicates meaning to the reader.",
                        "If it conveys information, replace alt=\"\" with a helpful description."
                    ),
                    solutionSnippet = "alt=\"Photo of ...\"",
                    canAutoFix = false
                )
            }
        }
        if (images.isNotEmpty() && imgMissingAlt == 0 && imgEmptyAlt == 0) {
            add(
                severity = FindingSeverity.PASS,
                category = AuditCategory.ACCESSIBILITY,
                title = "Image alt attributes present",
                detail = "All ${images.size} images have descriptive alt attributes."
            )
        }

        // Button accessible names
        val buttons = doc.select("button, input[type=button], input[type=submit], input[type=reset]")
        buttons.forEachIndexed { i, btn ->
            if (!hasAccessibleName(btn)) {
                add(
                    severity = FindingSeverity.ERROR,
                    category = AuditCategory.ACCESSIBILITY,
                    title = "Button lacks accessible name",
                    detail = "Button control ${i + 1} (<${btn.tagName()}>) has no discernible label.",
                    suggestedFix = "Add visible button text, an aria-label, or an aria-labelledby attribute.",
                    whyItMatters = "Users navigating via screen readers or voice control cannot activate a button whose function is unknown or blank.",
                    howToResolve = listOf(
                        "Add visible descriptive text inside the <button>...</button> tag.",
                        "If using an icon button, add an aria-label attribute (e.g., aria-label=\"Search documents\")."
                    ),
                    solutionSnippet = "<button type=\"button\" aria-label=\"Action description\">Action</button>",
                    canAutoFix = true
                )
            }
        }

        // Link accessible names and destinations
        val links = doc.select("a[href]")
        links.forEachIndexed { i, a ->
            val href = a.attr("href").trim()
            if (!hasAccessibleName(a)) {
                add(
                    severity = FindingSeverity.ERROR,
                    category = AuditCategory.ACCESSIBILITY,
                    title = "Link lacks accessible name",
                    detail = "Link ${i + 1} ($href) has no text or accessible name.",
                    suggestedFix = "Add descriptive anchor text or an aria-label attribute.",
                    whyItMatters = "Screen reader users frequently tab through links. Blank links prevent them from knowing where the link leads.",
                    howToResolve = listOf(
                        "Insert clear destination text between <a> and </a>.",
                        "Avoid generic 'click here'; describe the destination (e.g., 'View documentation')."
                    ),
                    solutionSnippet = "<a href=\"$href\">Descriptive Link Text</a>",
                    canAutoFix = true
                )
            }
            if (href.startsWith("#") && href.length > 1) {
                val targetId = try {
                    URLDecoder.decode(href.substring(1), "UTF-8")
                } catch (e: Exception) {
                    href.substring(1)
                }
                if (doc.getElementById(targetId) == null) {
                    add(
                        severity = FindingSeverity.WARNING,
                        category = AuditCategory.ACCESSIBILITY,
                        title = "Broken in-page link",
                        detail = "Link targets #$targetId, but no matching id=\"$targetId\" exists in DOM.",
                        suggestedFix = "Add matching id=\"$targetId\" to the destination element.",
                        whyItMatters = "Broken internal links cause navigation failure and disorientation for keyboard and assistive tech users.",
                        howToResolve = listOf(
                            "Find the destination section in your HTML.",
                            "Add id=\"$targetId\" to that heading or container element."
                        ),
                        solutionSnippet = "<h2 id=\"$targetId\">Section Title</h2>",
                        canAutoFix = false
                    )
                }
            } else if (href == "#") {
                add(
                    severity = FindingSeverity.WARNING,
                    category = AuditCategory.ACCESSIBILITY,
                    title = "Placeholder link href='#'",
                    detail = "Link uses href=\"#\", which is an unrouted placeholder.",
                    suggestedFix = "Use a valid URL or change to a <button> element.",
                    whyItMatters = "Links with href='#' jump to the page top and confuse screen readers. For scripting actions, buttons are the semantic standard.",
                    howToResolve = listOf(
                        "If triggering JavaScript or UI state: change <a> to <button type=\"button\">.",
                        "If navigating: provide the actual page URL."
                    ),
                    solutionSnippet = "<button type=\"button\">Interactive Action</button>",
                    canAutoFix = false
                )
            }
        }

        // Form control labels
        val formControls = doc.select("input:not([type=hidden]):not([type=button]):not([type=submit]):not([type=reset]), select, textarea")
        formControls.forEachIndexed { i, ctrl ->
            val id = ctrl.id()
            val hasExplicitLabel = id.isNotEmpty() && doc.select("label[for=$id]").any { it.text().trim().isNotEmpty() }
            val hasWrappedLabel = ctrl.parents().any { it.tagName().lowercase() == "label" && it.text().trim().isNotEmpty() }
            val hasAria = hasAccessibleName(ctrl)

            if (!hasExplicitLabel && !hasWrappedLabel && !hasAria) {
                val ctrlId = if (id.isNotEmpty()) id else "input_${i + 1}"
                add(
                    severity = FindingSeverity.ERROR,
                    category = AuditCategory.ACCESSIBILITY,
                    title = "Form control lacks label",
                    detail = "Control ${i + 1} (<${ctrl.tagName()}>) has no associated label.",
                    suggestedFix = "Add <label for=\"$ctrlId\"> or an aria-label attribute.",
                    whyItMatters = "Without an accessible label, users of screen readers hear only 'edit text' with no indication of what to input.",
                    howToResolve = listOf(
                        "Give the form input an id (e.g. id=\"email\").",
                        "Add a <label for=\"email\">Email Address</label> directly before the input."
                    ),
                    solutionSnippet = "<label for=\"$ctrlId\">Field Name</label>\n<${ctrl.tagName()} id=\"$ctrlId\">",
                    canAutoFix = true
                )
            }
        }

        // Table headers
        val tables = doc.select("table")
        tables.forEachIndexed { i, tbl ->
            if (tbl.select("th").isEmpty()) {
                add(
                    severity = FindingSeverity.WARNING,
                    category = AuditCategory.ACCESSIBILITY,
                    title = "Table missing header cells",
                    detail = "Table ${i + 1} contains no <th> header cells.",
                    suggestedFix = "Replace the first row's <td> with <th> cells.",
                    whyItMatters = "Screen readers use <th> cells to announce column and row associations as users navigate table data.",
                    howToResolve = listOf(
                        "In the first <tr> row of your table, change <td> to <th>.",
                        "Add scope=\"col\" to clarify column headers."
                    ),
                    solutionSnippet = "<tr><th scope=\"col\">Header 1</th><th scope=\"col\">Header 2</th></tr>",
                    canAutoFix = true
                )
            }
        }

        // ==========================================
        // 2. SEO Checks
        // ==========================================
        val titleText = doc.title().trim()
        if (titleText.isEmpty()) {
            add(
                severity = FindingSeverity.ERROR,
                category = AuditCategory.SEO,
                title = "Missing document title",
                detail = "The page has no <title> tag.",
                suggestedFix = "Add a meaningful <title> inside <head>.",
                whyItMatters = "The title is the primary anchor used by search engines, browser bookmarks, and screen readers to identify the document.",
                howToResolve = listOf(
                    "Open the <head> section of your HTML.",
                    "Add <title>Descriptive Page Name</title>."
                ),
                solutionSnippet = "<title>My Project Title</title>",
                canAutoFix = true
            )
        } else {
            add(
                severity = FindingSeverity.PASS,
                category = AuditCategory.SEO,
                title = "Document title present",
                detail = "Title: \"$titleText\"."
            )
        }

        val metaDesc = doc.selectFirst("meta[name=description i]")?.attr("content")?.trim() ?: ""
        if (metaDesc.isEmpty()) {
            add(
                severity = FindingSeverity.WARNING,
                category = AuditCategory.SEO,
                title = "Missing meta description",
                detail = "No meta description found.",
                suggestedFix = "Add <meta name=\"description\" content=\"...\"> to <head>.",
                whyItMatters = "Search engines display meta descriptions in search result snippets, directly influencing click-through rates.",
                howToResolve = listOf(
                    "In <head>, add <meta name=\"description\" content=\"...\">.",
                    "Keep length between 50 and 160 characters."
                ),
                solutionSnippet = "<meta name=\"description\" content=\"Concise summary of this page.\">",
                canAutoFix = true
            )
        } else {
            add(
                severity = FindingSeverity.PASS,
                category = AuditCategory.SEO,
                title = "Meta description present",
                detail = "Declared (${metaDesc.length} chars)."
            )
        }

        val h1s = doc.select("h1")
        when {
            h1s.isEmpty() -> {
                add(
                    severity = FindingSeverity.WARNING,
                    category = AuditCategory.SEO,
                    title = "No H1 heading found",
                    detail = "The document lacks a top-level <h1> heading.",
                    suggestedFix = "Add a single <h1> heading representing the main subject.",
                    whyItMatters = "An H1 heading provides search crawlers and readers with the primary topic of the page.",
                    howToResolve = listOf(
                        "Add <h1>Your Main Title</h1> at the start of your main content."
                    ),
                    solutionSnippet = "<h1>Main Document Heading</h1>",
                    canAutoFix = true
                )
            }
            h1s.size > 1 -> {
                add(
                    severity = FindingSeverity.WARNING,
                    category = AuditCategory.SEO,
                    title = "Multiple H1 headings",
                    detail = "Detected ${h1s.size} H1 headings.",
                    suggestedFix = "Reserve H1 for the page title and demote others to <h2>.",
                    whyItMatters = "Multiple H1 headings dilute topical focus and disrupt assistive technology heading outlines.",
                    howToResolve = listOf(
                        "Keep only the most important heading as <h1>.",
                        "Change secondary section titles to <h2>."
                    ),
                    solutionSnippet = "<h2>Secondary Section</h2>",
                    canAutoFix = false
                )
            }
            else -> {
                add(
                    severity = FindingSeverity.PASS,
                    category = AuditCategory.SEO,
                    title = "Primary H1 heading present",
                    detail = "Found H1: \"${h1s.first()?.text()?.take(35)}\"."
                )
            }
        }

        // ==========================================
        // 3. Performance & Mobile Checks
        // ==========================================
        val viewport = doc.selectFirst("meta[name=viewport i]")
        if (viewport == null) {
            add(
                severity = FindingSeverity.WARNING,
                category = AuditCategory.PERFORMANCE,
                title = "Missing viewport metadata",
                detail = "No mobile viewport configuration found.",
                suggestedFix = "Add standard mobile viewport meta tag.",
                whyItMatters = "Mobile browsers will render the page zoomed out at desktop scale, resulting in tiny unreadable text and layout breakages.",
                howToResolve = listOf(
                    "Add <meta name=\"viewport\" content=\"width=device-width, initial-scale=1\"> inside <head>."
                ),
                solutionSnippet = "<meta name=\"viewport\" content=\"width=device-width, initial-scale=1\">",
                canAutoFix = true
            )
        } else {
            add(
                severity = FindingSeverity.PASS,
                category = AuditCategory.PERFORMANCE,
                title = "Mobile viewport configured",
                detail = "Viewport metadata correctly configured."
            )
        }

        if (images.size > 1) {
            val nonLazy = images.drop(1).count { it.attr("loading").lowercase() != "lazy" }
            if (nonLazy > 0) {
                add(
                    severity = FindingSeverity.WARNING,
                    category = AuditCategory.PERFORMANCE,
                    title = "Secondary images lack lazy loading",
                    detail = "$nonLazy image(s) do not specify loading=\"lazy\".",
                    suggestedFix = "Add loading=\"lazy\" to offscreen images.",
                    whyItMatters = "Lazy loading defers downloading images until they enter the viewport, saving network bandwidth and speeding up Initial Page Load.",
                    howToResolve = listOf(
                        "Add loading=\"lazy\" to all <img> tags below the initial fold."
                    ),
                    solutionSnippet = "loading=\"lazy\"",
                    canAutoFix = true
                )
            } else {
                add(
                    severity = FindingSeverity.PASS,
                    category = AuditCategory.PERFORMANCE,
                    title = "Lazy loading enabled",
                    detail = "Secondary images use loading=\"lazy\"."
                )
            }
        }

        val targetBlanks = doc.select("a[target=_blank]")
        val unsafeBlanks = targetBlanks.filter {
            val rel = it.attr("rel").lowercase()
            !rel.contains("noopener") && !rel.contains("noreferrer")
        }
        if (unsafeBlanks.isNotEmpty()) {
            add(
                severity = FindingSeverity.WARNING,
                category = AuditCategory.PERFORMANCE,
                title = "External links lack noopener security",
                detail = "${unsafeBlanks.size} target=\"_blank\" link(s) lack rel=\"noopener noreferrer\".",
                suggestedFix = "Add rel=\"noopener noreferrer\" to external new-tab links.",
                whyItMatters = "Opening links in new tabs without rel=\"noopener\" exposes the page to reverse tab-nabbing vulnerabilities and performance thread lock.",
                howToResolve = listOf(
                    "Add rel=\"noopener noreferrer\" to every <a> tag with target=\"_blank\"."
                ),
                solutionSnippet = "rel=\"noopener noreferrer\"",
                canAutoFix = true
            )
        }

        // ==========================================
        // 4. Quality & Structure Checks
        // ==========================================
        val charset = doc.selectFirst("meta[charset], meta[http-equiv=Content-Type]")
        if (charset == null) {
            add(
                severity = FindingSeverity.WARNING,
                category = AuditCategory.QUALITY,
                title = "Missing charset declaration",
                detail = "No explicit character encoding declared.",
                suggestedFix = "Add <meta charset=\"utf-8\"> at the start of <head>.",
                whyItMatters = "Without explicit UTF-8 encoding, non-ASCII characters (including Urdu, Arabic, accents, and symbols) may render as broken garbled glyphs.",
                howToResolve = listOf(
                    "Insert <meta charset=\"utf-8\"> as the very first tag inside <head>."
                ),
                solutionSnippet = "<meta charset=\"utf-8\">",
                canAutoFix = true
            )
        } else {
            add(
                severity = FindingSeverity.PASS,
                category = AuditCategory.QUALITY,
                title = "Character encoding declared",
                detail = "Explicit charset declaration found."
            )
        }

        val idMap = mutableSetOf<String>()
        val duplicates = mutableSetOf<String>()
        doc.select("[id]").forEach { el ->
            val id = el.id().trim()
            if (id.isNotEmpty() && !idMap.add(id)) {
                duplicates.add(id)
            }
        }
        duplicates.forEach { dupId ->
            add(
                severity = FindingSeverity.ERROR,
                category = AuditCategory.QUALITY,
                title = "Duplicate element ID: #$dupId",
                detail = "The id=\"$dupId\" is assigned to multiple elements.",
                suggestedFix = "Change duplicate IDs to unique names.",
                whyItMatters = "HTML IDs must be unique. Duplicate IDs break JavaScript document.getElementById(), CSS styling, and screen reader aria references.",
                howToResolve = listOf(
                    "Search for id=\"$dupId\" across your document.",
                    "Rename subsequent occurrences (e.g. id=\"${dupId}_2\")."
                ),
                solutionSnippet = "id=\"${dupId}_unique\"",
                canAutoFix = false
            )
        }

        val headings = doc.select("h1, h2, h3, h4, h5, h6")
        var prevLvl = 0
        headings.forEach { h ->
            val lvl = h.tagName().removePrefix("h").toIntOrNull() ?: 0
            if (prevLvl > 0 && lvl > prevLvl + 1) {
                add(
                    severity = FindingSeverity.WARNING,
                    category = AuditCategory.QUALITY,
                    title = "Skipped heading level",
                    detail = "Heading jumps from H$prevLvl to H$lvl (\"${h.text().take(28)}\").",
                    suggestedFix = "Change H$lvl to H${prevLvl + 1} to maintain sequential order.",
                    whyItMatters = "Assistive technologies construct a table of contents from heading levels. Skipping levels disorients users relying on audio navigation.",
                    howToResolve = listOf(
                        "Change <h$lvl> to <h${prevLvl + 1}> for this heading."
                    ),
                    solutionSnippet = "<h${prevLvl + 1}>${h.text().take(30)}</h${prevLvl + 1}>",
                    canAutoFix = false
                )
            }
            prevLvl = lvl
        }

        val mainLandmark = doc.selectFirst("main, [role=main]")
        if (mainLandmark == null) {
            add(
                severity = FindingSeverity.WARNING,
                category = AuditCategory.QUALITY,
                title = "Missing main landmark",
                detail = "No <main> element was detected.",
                suggestedFix = "Wrap primary page content in <main>...</main>.",
                whyItMatters = "The <main> element allows assistive technology users to skip directly to the primary page content, bypassing headers and navigation bars.",
                howToResolve = listOf(
                    "Wrap the core body content of your page inside <main> and </main>."
                ),
                solutionSnippet = "<main>\n  <!-- Primary content here -->\n</main>",
                canAutoFix = true
            )
        } else {
            add(
                severity = FindingSeverity.PASS,
                category = AuditCategory.QUALITY,
                title = "Main landmark found",
                detail = "Semantic <main> content region found."
            )
        }

        val totalErrors = findings.count { it.severity == FindingSeverity.ERROR }
        val totalWarnings = findings.count { it.severity == FindingSeverity.WARNING }
        val totalPasses = findings.count { it.severity == FindingSeverity.PASS }
        val overallScore = maxOf(0, 100 - (totalErrors * 9) - (totalWarnings * 4))

        val categories = listOf(
            AuditCategory.ACCESSIBILITY to "Accessibility",
            AuditCategory.SEO to "SEO",
            AuditCategory.PERFORMANCE to "Performance",
            AuditCategory.QUALITY to "Quality & Structure"
        )

        val categoryScores = categories.map { (cat, name) ->
            val catFindings = findings.filter { it.category == cat }
            val e = catFindings.count { it.severity == FindingSeverity.ERROR }
            val w = catFindings.count { it.severity == FindingSeverity.WARNING }
            val p = catFindings.count { it.severity == FindingSeverity.PASS }
            val score = if (catFindings.isEmpty()) 100 else maxOf(0, 100 - (e * 14) - (w * 6))
            CategoryScore(
                category = cat,
                name = name,
                score = score,
                errorCount = e,
                warningCount = w,
                passCount = p
            )
        }

        return FluxReport(
            score = overallScore,
            errorsCount = totalErrors,
            warningsCount = totalWarnings,
            passesCount = totalPasses,
            applicableCount = totalErrors + totalWarnings + totalPasses,
            sourceSizeBytes = sourceSizeBytes,
            findings = findings,
            categoryScores = categoryScores
        )
    }

    private fun elementHasText(text: String?): Boolean = text != null && text.trim().isNotEmpty()

    fun applySafeFixes(html: String, targetLang: String = "en"): String {
        val trimmed = html.trim()
        if (trimmed.isEmpty()) return html
        val doc: Document = Jsoup.parse(trimmed)

        if (doc.selectFirst("meta[charset]") == null) {
            doc.head().prependElement("meta").attr("charset", "utf-8")
        }

        if (doc.selectFirst("meta[name=viewport i]") == null) {
            doc.head().appendElement("meta")
                .attr("name", "viewport")
                .attr("content", "width=device-width, initial-scale=1")
        }

        val htmlElement = doc.selectFirst("html")
        if (htmlElement != null && htmlElement.attr("lang").trim().isEmpty()) {
            htmlElement.attr("lang", targetLang)
        }

        if (doc.title().trim().isEmpty()) {
            doc.head().appendElement("title").text("MrMWSK Document")
        }

        doc.select("img:not([alt])").forEach { img ->
            img.attr("alt", "")
        }

        val images = doc.select("img")
        if (images.size > 1) {
            images.drop(1).forEach { img ->
                if (!img.hasAttr("loading")) {
                    img.attr("loading", "lazy")
                }
            }
        }

        doc.select("a[target=_blank]").forEach { link ->
            val rel = link.attr("rel")
            if (!rel.contains("noopener")) {
                link.attr("rel", if (rel.isBlank()) "noopener noreferrer" else "$rel noopener noreferrer")
            }
        }

        if (doc.selectFirst("main, [role=main]") == null) {
            val body = doc.body()
            if (body != null && body.children().isNotEmpty()) {
                val main = doc.createElement("main")
                val children = ArrayList(body.children())
                children.forEach { child ->
                    if (child.tagName() != "header" && child.tagName() != "footer") {
                        child.remove()
                        main.appendChild(child)
                    }
                }
                body.appendChild(main)
            }
        }

        return "<!doctype html>\n" + doc.outerHtml()
    }

    fun resolveSpecificFinding(html: String, finding: FluxFinding, targetLang: String = "en"): String {
        val trimmed = html.trim()
        if (trimmed.isEmpty()) return html
        val doc: Document = Jsoup.parse(trimmed)

        when {
            finding.title.contains("language", ignoreCase = true) -> {
                doc.selectFirst("html")?.attr("lang", targetLang)
            }
            finding.title.contains("charset", ignoreCase = true) -> {
                if (doc.selectFirst("meta[charset]") == null) {
                    doc.head().prependElement("meta").attr("charset", "utf-8")
                }
            }
            finding.title.contains("viewport", ignoreCase = true) -> {
                if (doc.selectFirst("meta[name=viewport i]") == null) {
                    doc.head().appendElement("meta").attr("name", "viewport").attr("content", "width=device-width, initial-scale=1")
                }
            }
            finding.title.contains("document title", ignoreCase = true) -> {
                if (doc.title().trim().isEmpty()) {
                    doc.head().appendElement("title").text("Document Title")
                }
            }
            finding.title.contains("meta description", ignoreCase = true) -> {
                if (doc.selectFirst("meta[name=description i]") == null) {
                    doc.head().appendElement("meta").attr("name", "description").attr("content", "Overview of this document.")
                }
            }
            finding.title.contains("alt text", ignoreCase = true) -> {
                doc.select("img:not([alt])").firstOrNull()?.attr("alt", "Descriptive image text")
            }
            finding.title.contains("button lacks", ignoreCase = true) -> {
                doc.select("button:empty").firstOrNull()?.text("Submit")
            }
            finding.title.contains("H1 heading", ignoreCase = true) -> {
                if (doc.select("h1").isEmpty()) {
                    doc.body().prependElement("h1").text("Main Title")
                }
            }
            finding.title.contains("table missing header", ignoreCase = true) -> {
                doc.select("table").firstOrNull()?.selectFirst("tr")?.select("td")?.forEach { td ->
                    td.tagName("th").attr("scope", "col")
                }
            }
            finding.title.contains("lazy loading", ignoreCase = true) -> {
                doc.select("img").drop(1).forEach { it.attr("loading", "lazy") }
            }
            finding.title.contains("noopener", ignoreCase = true) -> {
                doc.select("a[target=_blank]").forEach { link ->
                    val rel = link.attr("rel")
                    if (!rel.contains("noopener")) {
                        link.attr("rel", if (rel.isBlank()) "noopener noreferrer" else "$rel noopener noreferrer")
                    }
                }
            }
            finding.title.contains("main landmark", ignoreCase = true) -> {
                val body = doc.body()
                if (body != null) {
                    val main = doc.createElement("main")
                    val children = ArrayList(body.children())
                    children.forEach { child ->
                        if (child.tagName() != "header" && child.tagName() != "footer") {
                            child.remove()
                            main.appendChild(child)
                        }
                    }
                    body.appendChild(main)
                }
            }
        }
        return "<!doctype html>\n" + doc.outerHtml()
    }

    fun exportReportAsJson(report: FluxReport, documentName: String): String {
        val sb = java.lang.StringBuilder()
        sb.append("{\n")
        sb.append("  \"tool\": \"MrMWSK FLUX HTML Studio\",\n")
        sb.append("  \"document\": \"$documentName\",\n")
        sb.append("  \"score\": ${report.score},\n")
        sb.append("  \"errors\": ${report.errorsCount},\n")
        sb.append("  \"warnings\": ${report.warningsCount},\n")
        sb.append("  \"passed\": ${report.passesCount},\n")
        sb.append("  \"sourceSizeBytes\": ${report.sourceSizeBytes},\n")
        sb.append("  \"findings\": [\n")
        report.findings.forEachIndexed { i, f ->
            val escapedTitle = f.title.replace("\"", "\\\"")
            val escapedDetail = f.detail.replace("\"", "\\\"")
            val escapedFix = f.suggestedFix.replace("\"", "\\\"")
            sb.append("    {\n")
            sb.append("      \"id\": \"${f.id}\",\n")
            sb.append("      \"severity\": \"${f.severity}\",\n")
            sb.append("      \"category\": \"${f.category}\",\n")
            sb.append("      \"title\": \"$escapedTitle\",\n")
            sb.append("      \"detail\": \"$escapedDetail\",\n")
            sb.append("      \"suggestedFix\": \"$escapedFix\",\n")
            sb.append("      \"canAutoFix\": ${f.canAutoFix}\n")
            sb.append("    }")
            if (i < report.findings.size - 1) sb.append(",")
            sb.append("\n")
        }
        sb.append("  ]\n")
        sb.append("}")
        return sb.toString()
    }

    fun exportReportAsCsv(report: FluxReport, documentName: String): String {
        val sb = java.lang.StringBuilder()
        sb.append("ID,Severity,Category,Title,Detail,Suggested Fix\n")
        report.findings.forEach { f ->
            val cleanTitle = f.title.replace("\"", "\"\"")
            val cleanDetail = f.detail.replace("\"", "\"\"")
            val cleanFix = f.suggestedFix.replace("\"", "\"\"")
            sb.append("\"${f.id}\",\"${f.severity}\",\"${f.category}\",\"$cleanTitle\",\"$cleanDetail\",\"$cleanFix\"\n")
        }
        return sb.toString()
    }
}
