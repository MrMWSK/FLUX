package com.example

import com.example.data.model.FindingSeverity
import com.example.data.model.SampleDocuments
import com.example.domain.FluxEngine
import com.example.domain.OpenLeafEngine
import com.example.domain.RenderBlock
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test

class ExampleUnitTest {

    @Test
    fun testFluxEngine_analyzesSampleAndFlagsIssues() {
        val sample = SampleDocuments.FLUX_TEST_SAMPLE
        val report = FluxEngine.analyzeHtml(sample)

        assertNotNull(report)
        assertTrue("Report should have findings", report.findings.isNotEmpty())
        assertTrue("Score should reflect issues in the test sample", report.score < 100)
        assertTrue("Should have errors", report.errorsCount > 0)
        assertTrue("Should have warnings", report.warningsCount > 0)

        // Verify specific finding detections
        val hasMissingLang = report.findings.any { it.title.contains("language", ignoreCase = true) && it.severity == FindingSeverity.ERROR }
        val hasMissingViewport = report.findings.any { it.title.contains("viewport", ignoreCase = true) }
        val hasDuplicateId = report.findings.any { it.title.contains("duplicate", ignoreCase = true) }

        assertTrue("Should detect missing lang", hasMissingLang)
        assertTrue("Should detect missing viewport", hasMissingViewport)
        assertTrue("Should detect duplicate ID", hasDuplicateId)
    }

    @Test
    fun testFluxEngine_safeFixesInjectsMissingTags() {
        val brokenHtml = "<html><head></head><body><p>Hello world</p><img src='test.jpg'></body></html>"
        val fixed = FluxEngine.applySafeFixes(brokenHtml, targetLang = "ur")

        assertTrue("Fixed HTML should declare charset", fixed.contains("charset=\"utf-8\"") || fixed.contains("charset=utf-8"))
        assertTrue("Fixed HTML should declare viewport", fixed.contains("name=\"viewport\"") || fixed.contains("viewport"))
        assertTrue("Fixed HTML should declare lang='ur'", fixed.contains("lang=\"ur\""))
        assertTrue("Fixed HTML should add empty alt to images", fixed.contains("alt=\"\""))
    }

    @Test
    fun testOpenLeafEngine_sanitizationAndLanguageDetection() {
        val unsafeHtml = """
            <!doctype html>
            <html>
            <head><title>Test Book</title></head>
            <body>
              <script>alert('malicious')</script>
              <h1 id="sec-1">First Chapter</h1>
              <p onclick="steal()">Safe English paragraph text.</p>
              <div class="urdu" lang="ur">
                <p>ہزاروں خواہشیں ایسی کہ ہر خواہش پہ دم نکلے</p>
              </div>
            </body>
            </html>
        """.trimIndent()

        val result = OpenLeafEngine.parse(unsafeHtml)

        // Verify scripts and on-handlers are stripped
        assertFalse("Cleaned HTML must not contain script tags", result.cleanedHtml.contains("<script>"))
        assertFalse("Cleaned HTML must not contain onclick handlers", result.cleanedHtml.contains("onclick"))

        // Verify TOC
        assertEquals(1, result.toc.size)
        assertEquals("First Chapter", result.toc[0].title)

        // Verify Urdu detection
        assertTrue("Should detect Urdu sections", result.stats.urduSectionsCount > 0)
    }
}
